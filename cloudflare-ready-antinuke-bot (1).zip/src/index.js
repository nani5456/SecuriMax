import 'dotenv/config';
import { Client, GatewayIntentBits, Partials } from 'discord.js';
import { connectDB }    from './database/connect.js';
import { loadCommands } from './handlers/commandHandler.js';
import { loadEvents }   from './handlers/eventHandler.js';
import { startOAuthServer, setClient } from './server/oauth.js';

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildBans,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.DirectMessages,
    ],
    partials: [Partials.Channel, Partials.GuildMember, Partials.Message],
});

setClient(client);

// Connect DB → start OAuth server → register events → login → register commands
await connectDB();
startOAuthServer();
loadEvents(client);

client.login(process.env.DISCORD_TOKEN).then(async () => {
    await loadCommands(client);
});

process.on('unhandledRejection', err => console.error('[UNHANDLED]', err));
process.on('uncaughtException',  err => console.error('[UNCAUGHT]',  err));

export { client };
