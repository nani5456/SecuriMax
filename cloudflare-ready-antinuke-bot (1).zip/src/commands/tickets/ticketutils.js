import { SlashCommandBuilder } from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import Ticket from '../../database/schemas/Ticket.js';
import GuildConfig from '../../database/schemas/GuildConfig.js';

// ─── /ticketadd ───────────────────────────────────────────────────────────────
export const ticketadd = {
    data: new SlashCommandBuilder()
        .setName('ticketadd')
        .setDescription('Add a user to the current ticket.')
        .setDMPermission(false)
        .addUserOption(o => o.setName('user').setDescription('User to add').setRequired(true)),

    async execute({ interaction }) {
        const { guild, user, channel } = interaction;
        const ticket = await Ticket.findOne({ channelId: channel.id, status: 'open' });
        if (!ticket) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'This is not an active ticket.'), flags: RocksUI.getFlags(true) });

        const cfg      = await GuildConfig.findOne({ guildId: guild.id });
        const staffRoles = ticket.type === 'middleman' ? cfg?.tickets?.mmStaffRoles : cfg?.tickets?.supportStaffRoles;
        const isStaff  = staffRoles?.some(r => interaction.member.roles.cache.has(r));
        if (!isStaff && guild.ownerId !== user.id) {
            return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only staff can add users to tickets.'), flags: RocksUI.getFlags(true) });
        }

        const target = interaction.options.getUser('user');
        await channel.permissionOverwrites.edit(target.id, {
            ViewChannel: true, SendMessages: true, ReadMessageHistory: true,
        });

        return interaction.reply({ components: RocksUI.buildStatusMessage('tick', `<@${target.id}> has been added to the ticket.`), flags: RocksUI.getFlags() });
    },
};

// ─── /rename ──────────────────────────────────────────────────────────────────
export const rename = {
    data: new SlashCommandBuilder()
        .setName('rename')
        .setDescription('Rename the current ticket channel.')
        .setDMPermission(false)
        .addStringOption(o => o.setName('name').setDescription('New channel name').setRequired(true)),

    async execute({ interaction }) {
        const { guild, user, channel } = interaction;
        const ticket = await Ticket.findOne({ channelId: channel.id, status: 'open' });
        if (!ticket) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'This is not an active ticket.'), flags: RocksUI.getFlags(true) });

        const cfg      = await GuildConfig.findOne({ guildId: guild.id });
        const staffRoles = ticket.type === 'middleman' ? cfg?.tickets?.mmStaffRoles : cfg?.tickets?.supportStaffRoles;
        const isStaff  = staffRoles?.some(r => interaction.member.roles.cache.has(r));
        if (!isStaff && guild.ownerId !== user.id) {
            return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only staff can rename tickets.'), flags: RocksUI.getFlags(true) });
        }

        const name = interaction.options.getString('name').toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
        await channel.setName(name);
        return interaction.reply({ components: RocksUI.buildStatusMessage('tick', `Channel renamed to **${name}**.`), flags: RocksUI.getFlags() });
    },
};
