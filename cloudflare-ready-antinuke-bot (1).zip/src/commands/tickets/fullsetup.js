import {
    SlashCommandBuilder, PermissionFlagsBits, ChannelType,
    ActionRowBuilder, ChannelSelectMenuBuilder, RoleSelectMenuBuilder,
} from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import { isAuthorized } from '../../utils/permCheck.js';
import GuildConfig from '../../database/schemas/GuildConfig.js';

export default {
    data: new SlashCommandBuilder()
        .setName('fullsetup')
        .setDescription('Setup wizard for ticket system.')
        .setDMPermission(false)
        .addSubcommand(s => s.setName('wizard').setDescription('Start the setup wizard.'))
        .addSubcommand(s => s.setName('reset').setDescription('Reset all ticket config.')),

    async execute({ interaction }) {
        const { guild, user } = interaction;
        if (!await isAuthorized(guild, user.id)) {
            return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only **server owner** or **extra owner** can use this.'), flags: RocksUI.getFlags(true) });
        }

        const sub = interaction.options.getSubcommand();

        if (sub === 'reset') {
            await interaction.deferReply({ flags: RocksUI.getFlags() });
            await GuildConfig.findOneAndUpdate({ guildId: guild.id }, { tickets: {} }, { upsert: true });
            return interaction.editReply({ components: RocksUI.buildStatusMessage('tick', 'Ticket configuration reset.'), flags: RocksUI.getFlags() });
        }

        // Wizard
        await interaction.deferReply({ flags: RocksUI.getFlags() });

        let data = { mmCategoryId: null, supportCategoryId: null, mmStaffRoles: [], supportStaffRoles: [], ticketLogChannel: null, hitLogChannel: null, ontopRole: null };

        const steps = [
            { id: 'mm_category',       title: 'Step 1: Middleman Category',      desc: 'Select the **category** for Middleman tickets.',      comp: new ChannelSelectMenuBuilder().setCustomId('wiz_mm_cat').setPlaceholder('Select Category').addChannelTypes(ChannelType.GuildCategory) },
            { id: 'support_category',  title: 'Step 2: Support Category',        desc: 'Select the **category** for Support tickets.',        comp: new ChannelSelectMenuBuilder().setCustomId('wiz_sup_cat').setPlaceholder('Select Category').addChannelTypes(ChannelType.GuildCategory) },
            { id: 'mm_staff',          title: 'Step 3: Middleman Staff Roles',   desc: 'Select roles for **Middleman** ticket access.',       comp: new RoleSelectMenuBuilder().setCustomId('wiz_mm_staff').setPlaceholder('Select Roles').setMinValues(1).setMaxValues(10) },
            { id: 'support_staff',     title: 'Step 4: Support Staff Roles',     desc: 'Select roles for **Support** ticket access.',        comp: new RoleSelectMenuBuilder().setCustomId('wiz_sup_staff').setPlaceholder('Select Roles').setMinValues(1).setMaxValues(10) },
            { id: 'log_channel',       title: 'Step 5: Ticket Log Channel',      desc: 'Select where **ticket transcripts** are sent.',       comp: new ChannelSelectMenuBuilder().setCustomId('wiz_log_ch').setPlaceholder('Select Channel').addChannelTypes(ChannelType.GuildText) },
            { id: 'hit_log_channel',   title: 'Step 6: Hit Log Channel',         desc: 'Select where **hit logs** are posted.',               comp: new ChannelSelectMenuBuilder().setCustomId('wiz_hit_ch').setPlaceholder('Select Channel').addChannelTypes(ChannelType.GuildText) },
            { id: 'ontop_role',        title: 'Step 7: Ontop Role',              desc: 'Select the role for the **Ontop Protocol**.',         comp: new RoleSelectMenuBuilder().setCustomId('wiz_ontop').setPlaceholder('Select Role') },
        ];

        let step = 0;

        const showStep = async () => {
            const s   = steps[step];
            const row = new ActionRowBuilder().addComponents(s.comp);
            await interaction.editReply({ components: RocksUI.buildDashboard(`# ${config.emojis.arrow} ${s.title}`, s.desc, [row]), flags: RocksUI.getFlags() });
        };

        await showStep();

        const msg       = await interaction.fetchReply();
        const collector = msg.createMessageComponentCollector({ filter: i => i.user.id === user.id, time: 300000 });

        collector.on('collect', async i => {
            await i.deferUpdate();
            const sid = steps[step].id;
            if (i.isChannelSelectMenu()) {
                if (sid === 'mm_category')      data.mmCategoryId     = i.values[0];
                else if (sid === 'support_category') data.supportCategoryId = i.values[0];
                else if (sid === 'log_channel')  data.ticketLogChannel = i.values[0];
                else if (sid === 'hit_log_channel') data.hitLogChannel  = i.values[0];
            } else if (i.isRoleSelectMenu()) {
                if (sid === 'mm_staff')         data.mmStaffRoles    = i.values;
                else if (sid === 'support_staff') data.supportStaffRoles = i.values;
                else if (sid === 'ontop_role')  data.ontopRole       = i.values[0];
            }
            step++;
            if (step < steps.length) await showStep();
            else collector.stop('done');
        });

        collector.on('end', async (_, reason) => {
            if (reason === 'done') {
                await GuildConfig.findOneAndUpdate(
                    { guildId: guild.id },
                    { tickets: { enabled: true, ...data } },
                    { upsert: true }
                );
                return interaction.editReply({ components: RocksUI.buildDetailedDashboard(
                    `# ${config.emojis.tick} Setup Complete`,
                    'All ticket systems are configured.',
                    [
                        { name: 'MM Category',      value: `<#${data.mmCategoryId}>` },
                        { name: 'Support Category', value: `<#${data.supportCategoryId}>` },
                        { name: 'MM Staff',         value: data.mmStaffRoles.map(r => `<@&${r}>`).join(', ') || 'None' },
                        { name: 'Support Staff',    value: data.supportStaffRoles.map(r => `<@&${r}>`).join(', ') || 'None' },
                        { name: 'Ticket Log',       value: `<#${data.ticketLogChannel}>` },
                        { name: 'Ontop Role',       value: data.ontopRole ? `<@&${data.ontopRole}>` : 'None' },
                    ]
                ), flags: RocksUI.getFlags() });
            } else {
                return interaction.editReply({ components: RocksUI.buildStatusMessage('error', 'Setup wizard timed out.'), flags: RocksUI.getFlags() }).catch(() => {});
            }
        });
    },
};
