import {
    SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
    ChannelType, PermissionFlagsBits, ContainerBuilder,
    TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags,
} from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import { isAuthorized } from '../../utils/permCheck.js';
import GuildConfig from '../../database/schemas/GuildConfig.js';
import Ticket from '../../database/schemas/Ticket.js';

// ─── Open a ticket ────────────────────────────────────────────────────────────
export async function openTicket(guild, user, type, cfg) {
    const categoryId = type === 'middleman' ? cfg.tickets.mmCategoryId : cfg.tickets.supportCategoryId;
    const staffRoles = type === 'middleman' ? cfg.tickets.mmStaffRoles  : cfg.tickets.supportStaffRoles;

    if (!categoryId) throw new Error(`No category configured for ${type} tickets. Run \`/fullsetup wizard\` first.`);

    // Check for existing open ticket
    const existing = await Ticket.findOne({ guildId: guild.id, userId: user.id, status: 'open', type });
    if (existing) {
        const ch = guild.channels.cache.get(existing.channelId);
        if (ch) throw new Error(`You already have an open ${type} ticket: <#${existing.channelId}>`);
        else await Ticket.deleteOne({ _id: existing._id });
    }

    const count = await Ticket.countDocuments({ guildId: guild.id }) + 1;

    // Permission overwrites
    const overwrites = [
        { id: guild.id,          deny: [PermissionFlagsBits.ViewChannel] },
        { id: user.id,           allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: guild.members.me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages] },
    ];
    staffRoles.forEach(rId => overwrites.push({
        id: rId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    }));

    const channel = await guild.channels.create({
        name: `${type === 'middleman' ? 'mm' : 'ticket'}-${count.toString().padStart(4, '0')}`,
        type: ChannelType.GuildText,
        parent: categoryId,
        permissionOverwrites: overwrites,
    });

    // Save ticket
    await Ticket.create({ guildId: guild.id, channelId: channel.id, userId: user.id, username: user.username, type, ticketNumber: count });

    // Post ticket embed in channel
    const closeRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`ticket_close_${channel.id}`).setLabel('🔒 Close Ticket').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId(`ticket_claim_${channel.id}`).setLabel('✋ Claim').setStyle(ButtonStyle.Secondary),
    );

    const container = new ContainerBuilder();
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `### ${config.emojis.vip} ${type === 'middleman' ? 'Middleman' : 'Support'} Ticket #${count}\n`
    ));
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `${config.emojis.dot} **Opened by:** <@${user.id}>\n` +
        `${config.emojis.dot} **Type:** ${type === 'middleman' ? 'Middleman Trade' : 'Support Request'}\n\n` +
        `${config.emojis.arrow} Staff will be with you shortly. Please describe your issue.`
    ));
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
    container.addActionRowComponents(closeRow);
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));

    await channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });

    // Ping staff roles
    if (staffRoles.length) await channel.send(staffRoles.map(r => `<@&${r}>`).join(' ')).then(m => m.delete().catch(() => {})).catch(() => {});

    return channel;
}

// ─── /panel command ───────────────────────────────────────────────────────────
export default {
    data: new SlashCommandBuilder()
        .setName('panel')
        .setDescription('Post the ticket panel in this channel.')
        .setDMPermission(false),

    async execute({ interaction }) {
        const { guild, user, channel } = interaction;
        if (!await isAuthorized(guild, user.id)) {
            return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only **server owner** or **extra owner** can post the ticket panel.'), flags: RocksUI.getFlags(true) });
        }

        const cfg = await GuildConfig.findOne({ guildId: guild.id });
        if (!cfg?.tickets?.mmCategoryId && !cfg?.tickets?.supportCategoryId) {
            return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Ticket system not configured. Run `/fullsetup wizard` first.'), flags: RocksUI.getFlags(true) });
        }

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('ticket_open_middleman').setLabel('⚔️ Middleman').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('ticket_open_support').setLabel('🎧 Support').setStyle(ButtonStyle.Secondary),
        );

        const container = new ContainerBuilder();
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `### ${config.emojis.vip} Support & Middleman Tickets`
        ));
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `${config.emojis.dot} **⚔️ Middleman** — Need a trusted middleman for a trade?\n` +
            `${config.emojis.dot} **🎧 Support** — Have a question or need help?\n\n` +
            `${config.emojis.arrow} Click a button below to open a ticket.`
        ));
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
        container.addActionRowComponents(row);
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));

        await channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        return interaction.reply({ components: RocksUI.buildStatusMessage('tick', 'Ticket panel posted!'), flags: RocksUI.getFlags(true) });
    },

    // Handle ticket open buttons
    async handleOpenButton(interaction, client) {
        const { guild, user, customId } = interaction;
        const type = customId === 'ticket_open_middleman' ? 'middleman' : 'support';

        await interaction.deferReply({ flags: RocksUI.getFlags(true) });

        const cfg = await GuildConfig.findOne({ guildId: guild.id });
        if (!cfg?.tickets?.mmCategoryId && !cfg?.tickets?.supportCategoryId) {
            return interaction.editReply({ components: RocksUI.buildStatusMessage('error', 'Ticket system not set up.'), flags: RocksUI.getFlags() });
        }

        try {
            const channel = await openTicket(guild, user, type, cfg);
            return interaction.editReply({ components: RocksUI.buildStatusMessage('tick', `Ticket opened: <#${channel.id}>`), flags: RocksUI.getFlags() });
        } catch (err) {
            return interaction.editReply({ components: RocksUI.buildStatusMessage('error', err.message), flags: RocksUI.getFlags() });
        }
    },
};
