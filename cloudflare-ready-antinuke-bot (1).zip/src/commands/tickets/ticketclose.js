import { SlashCommandBuilder, ChannelType } from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import GuildConfig from '../../database/schemas/GuildConfig.js';
import Ticket from '../../database/schemas/Ticket.js';

async function closeTicket(interaction, channel) {
    const { guild, user } = interaction;
    const ticket = await Ticket.findOne({ channelId: channel.id, status: 'open' });

    if (!ticket) {
        return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'This is not an active ticket channel.'), flags: RocksUI.getFlags(true) });
    }

    const cfg        = await GuildConfig.findOne({ guildId: guild.id });
    const staffRoles = ticket.type === 'middleman' ? cfg?.tickets?.mmStaffRoles : cfg?.tickets?.supportStaffRoles;
    const isStaff    = staffRoles?.some(r => interaction.member.roles.cache.has(r));
    const isOwner    = ticket.userId === user.id;

    if (!isStaff && !isOwner && guild.ownerId !== user.id) {
        return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only staff or the ticket opener can close this.'), flags: RocksUI.getFlags(true) });
    }

    await interaction.reply({ components: RocksUI.buildStatusMessage('loader', 'Closing ticket...'), flags: RocksUI.getFlags() });

    ticket.status = 'closed';
    await ticket.save();

    // Log transcript if channel configured
    if (cfg?.tickets?.ticketLogChannel) {
        const logCh = guild.channels.cache.get(cfg.tickets.ticketLogChannel);
        if (logCh) {
            const msgs = await channel.messages.fetch({ limit: 100 }).catch(() => null);
            const transcript = msgs
                ? [...msgs.values()].reverse().map(m => `[${m.createdAt.toISOString()}] ${m.author.tag}: ${m.content}`).join('\n')
                : 'No messages.';
            const { AttachmentBuilder } = await import('discord.js');
            const file = new AttachmentBuilder(Buffer.from(transcript), { name: `ticket-${ticket.ticketNumber}.txt` });
            await logCh.send({
                components: RocksUI.buildDetailedDashboard(`# ${config.emojis.dot} Ticket Closed`, null, [
                    { name: 'Ticket', value: `#${ticket.ticketNumber}` },
                    { name: 'Opened by', value: `<@${ticket.userId}>` },
                    { name: 'Type', value: ticket.type },
                    { name: 'Closed by', value: `<@${user.id}>` },
                ]),
                files: [file],
                flags: RocksUI.getFlags(),
            }).catch(() => {});
        }
    }

    // Delete channel after 5 seconds
    setTimeout(() => channel.delete('[Ticket] Closed.').catch(() => {}), 5000);
}

export default {
    data: new SlashCommandBuilder()
        .setName('ticketclose')
        .setDescription('Close the current ticket.')
        .setDMPermission(false),

    async execute({ interaction }) {
        await closeTicket(interaction, interaction.channel);
    },

    // Handle close button
    async handleCloseButton(interaction) {
        const channelId = interaction.customId.replace('ticket_close_', '');
        const channel   = interaction.guild.channels.cache.get(channelId);
        if (!channel) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Channel not found.'), flags: RocksUI.getFlags(true) });
        await closeTicket(interaction, channel);
    },

    // Handle claim button
    async handleClaimButton(interaction) {
        const channelId = interaction.customId.replace('ticket_claim_', '');
        const ticket    = await Ticket.findOne({ channelId });
        if (!ticket) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Ticket not found.'), flags: RocksUI.getFlags(true) });
        if (ticket.claimedBy) return interaction.reply({ components: RocksUI.buildStatusMessage('error', `Already claimed by <@${ticket.claimedBy}>.`), flags: RocksUI.getFlags(true) });
        ticket.claimedBy = interaction.user.id;
        await ticket.save();
        return interaction.reply({ components: RocksUI.buildStatusMessage('tick', `Ticket claimed by <@${interaction.user.id}>.`), flags: RocksUI.getFlags() });
    },
};
