import { SlashCommandBuilder } from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import GuildConfig from '../../database/schemas/GuildConfig.js';

export default {
    data: new SlashCommandBuilder().setName('extraowner').setDescription('Manage extra owners.').setDMPermission(false)
        .addSubcommand(s => s.setName('add').setDescription('Add extra owner.').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
        .addSubcommand(s => s.setName('remove').setDescription('Remove extra owner.').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
        .addSubcommand(s => s.setName('list').setDescription('List extra owners.')),

    async execute({ interaction }) {
        const { guild, user } = interaction;
        if (guild.ownerId !== user.id) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only the **server owner** can manage extra owners.'), flags: RocksUI.getFlags(true) });

        const sub = interaction.options.getSubcommand();
        const cfg = await GuildConfig.findOneAndUpdate({ guildId: guild.id }, {}, { upsert: true, new: true });

        if (sub === 'add') {
            const target = interaction.options.getUser('user');
            if (target.id === guild.ownerId) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Cannot add server owner.'), flags: RocksUI.getFlags(true) });
            if (cfg.extraOwners.includes(target.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', `**${target.username}** is already an extra owner.`), flags: RocksUI.getFlags(true) });
            await GuildConfig.findOneAndUpdate({ guildId: guild.id }, { $push: { extraOwners: target.id } });
            return interaction.reply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} Extra Owner Added`, null, [{ name: 'User', value: `${target.username} (${target.id})` }, { name: 'Total', value: `${cfg.extraOwners.length + 1}` }]), flags: RocksUI.getFlags(true) });
        }
        if (sub === 'remove') {
            const target = interaction.options.getUser('user');
            if (!cfg.extraOwners.includes(target.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', `**${target.username}** is not an extra owner.`), flags: RocksUI.getFlags(true) });
            await GuildConfig.findOneAndUpdate({ guildId: guild.id }, { $pull: { extraOwners: target.id } });
            return interaction.reply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} Extra Owner Removed`, null, [{ name: 'User', value: `${target.username} (${target.id})` }]), flags: RocksUI.getFlags(true) });
        }
        if (sub === 'list') {
            const lines = cfg.extraOwners.length ? cfg.extraOwners.map((id, i) => `${config.emojis.dot} **${i + 1}.** <@${id}> (\`${id}\`)`).join('\n') : `${config.emojis.dot} No extra owners.`;
            return interaction.reply({ components: RocksUI.buildDashboard(`# ${config.emojis.dot} Extra Owners — ${guild.name}`, lines), flags: RocksUI.getFlags(true) });
        }
    },
};
