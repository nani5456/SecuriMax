import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import { isAuthorized, getOrCreateConfig } from '../../utils/permCheck.js';
import GuildConfig from '../../database/schemas/GuildConfig.js';

const PAGE_SIZE = 5;

// ─── Build the modules page ───────────────────────────────────────────────────
async function buildModulesPage(guild, page = 0) {
    const cfg     = await getOrCreateConfig(guild.id);
    const modules = config.antinuke.modules;
    const total   = Math.ceil(modules.length / PAGE_SIZE);
    const slice   = modules.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

    // Count enabled modules
    const enabledCount = modules.filter(m => cfg.antinuke?.[m.key]).length;

    const lines = slice.map((m, i) => {
        const on = cfg.antinuke?.[m.key];
        return `${on ? config.emojis.tick : config.emojis.cross} **${m.label}**`;
    }).join('\n');

    const desc =
        `${config.emojis.dot} **${enabledCount}/${modules.length}** modules enabled\n` +
        `${config.emojis.arrow} Page **${page + 1}/${total}** — tap a number to toggle\n\n` +
        lines;

    // Number buttons to toggle each module on this page
    const toggleRow = new ActionRowBuilder().addComponents(
        slice.map((m, i) => new ButtonBuilder()
            .setCustomId(`an_tog_${m.key}_${page}`)
            .setLabel(`${i + 1}`)
            .setStyle(cfg.antinuke?.[m.key] ? ButtonStyle.Success : ButtonStyle.Danger)
        )
    );

    // Nav + bulk actions
    const navRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`an_prev_${page}`).setLabel('◀').setStyle(ButtonStyle.Secondary).setDisabled(page === 0),
        new ButtonBuilder().setCustomId(`an_next_${page}`).setLabel('▶').setStyle(ButtonStyle.Secondary).setDisabled(page >= total - 1),
        new ButtonBuilder().setCustomId(`an_all_on_${page}`).setLabel('✅ All On').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`an_all_off_${page}`).setLabel('❌ All Off').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('an_close').setLabel('✖ Close').setStyle(ButtonStyle.Secondary),
    );

    return { desc, rows: [toggleRow, navRow] };
}

// ─── Build the main overview (1 button) ──────────────────────────────────────
async function buildOverview(guild) {
    const cfg          = await getOrCreateConfig(guild.id);
    const modules      = config.antinuke.modules;
    const enabledCount = modules.filter(m => cfg.antinuke?.[m.key]).length;
    const allOn        = enabledCount === modules.length;
    const allOff       = enabledCount === 0;

    const status = allOn ? `${config.emojis.tick} **All modules enabled**`
                 : allOff ? `${config.emojis.cross} **All modules disabled**`
                 : `${config.emojis.loader} **${enabledCount}/${modules.length}** modules active`;

    const desc =
        `${config.emojis.vip} **AntiNuke Protection Panel**\n\n` +
        `${status}\n\n` +
        `${config.emojis.dot} Click **Manage Modules** to toggle individual protections.\n` +
        `${config.emojis.dot} Only the server owner and extra owners can change settings.`;

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('an_open_modules')
            .setLabel('⚙️ Manage Modules')
            .setStyle(ButtonStyle.Primary),
    );

    return { desc, rows: [row] };
}

export default {
    data: new SlashCommandBuilder()
        .setName('antinuke')
        .setDescription('Manage antinuke protection.')
        .setDMPermission(false),

    async execute({ interaction }) {
        const { guild, user } = interaction;
        if (!await isAuthorized(guild, user.id)) {
            return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only the **server owner** or **extra owner** can use this.'), flags: RocksUI.getFlags(true) });
        }

        const { desc, rows } = await buildOverview(guild);
        return interaction.reply({
            components: RocksUI.buildDashboard(`# ${config.emojis.vip} AntiNuke — ${guild.name}`, desc, rows),
            flags: RocksUI.getFlags(true),
        });
    },

    async handleButton(interaction) {
        const { guild, user, customId } = interaction;
        if (!await isAuthorized(guild, user.id)) {
            return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Not authorized.'), flags: RocksUI.getFlags(true) });
        }

        // Open modules panel
        if (customId === 'an_open_modules') {
            const { desc, rows } = await buildModulesPage(guild, 0);
            return interaction.update({
                components: RocksUI.buildDashboard(`# ${config.emojis.vip} AntiNuke Modules — ${guild.name}`, desc, rows),
                flags: RocksUI.getFlags(),
            });
        }

        // Close back to overview
        if (customId === 'an_close') {
            const { desc, rows } = await buildOverview(guild);
            return interaction.update({
                components: RocksUI.buildDashboard(`# ${config.emojis.vip} AntiNuke — ${guild.name}`, desc, rows),
                flags: RocksUI.getFlags(),
            });
        }

        // Toggle a module
        if (customId.startsWith('an_tog_')) {
            const parts = customId.replace('an_tog_', '').split('_');
            const page  = parseInt(parts.pop());
            const key   = parts.join('_');

            const cfg = await getOrCreateConfig(guild.id);
            cfg.antinuke[key] = !cfg.antinuke[key];
            await GuildConfig.findOneAndUpdate({ guildId: guild.id }, { [`antinuke.${key}`]: cfg.antinuke[key] }, { upsert: true });

            const { desc, rows } = await buildModulesPage(guild, page);
            return interaction.update({
                components: RocksUI.buildDashboard(`# ${config.emojis.vip} AntiNuke Modules — ${guild.name}`, desc, rows),
                flags: RocksUI.getFlags(),
            });
        }

        // Enable/disable all
        if (customId.startsWith('an_all_on_') || customId.startsWith('an_all_off_')) {
            const enable = customId.startsWith('an_all_on_');
            const page   = parseInt(customId.split('_').pop());
            const update = {};
            config.antinuke.modules.forEach(m => { update[`antinuke.${m.key}`] = enable; });
            await GuildConfig.findOneAndUpdate({ guildId: guild.id }, update, { upsert: true });

            const { desc, rows } = await buildModulesPage(guild, page);
            return interaction.update({
                components: RocksUI.buildDashboard(`# ${config.emojis.vip} AntiNuke Modules — ${guild.name}`, desc, rows),
                flags: RocksUI.getFlags(),
            });
        }

        // Pagination
        if (customId.startsWith('an_prev_') || customId.startsWith('an_next_')) {
            const cur  = parseInt(customId.split('_').pop());
            const page = customId.startsWith('an_next_') ? cur + 1 : cur - 1;
            const { desc, rows } = await buildModulesPage(guild, page);
            return interaction.update({
                components: RocksUI.buildDashboard(`# ${config.emojis.vip} AntiNuke Modules — ${guild.name}`, desc, rows),
                flags: RocksUI.getFlags(),
            });
        }
    },
};
