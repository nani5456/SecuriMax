import { SlashCommandBuilder } from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import { isPremiumAuthorized, isAuthorized, isBotOwner } from '../../utils/permCheck.js';
import { getValidToken, sleep } from '../../utils/tokenManager.js';
import { forceAddToGuild } from '../../server/oauth.js';
import BackupUser from '../../database/schemas/BackupUser.js';

// ─── /pullmember ──────────────────────────────────────────────────────────────
export const pullmember = {
    data: new SlashCommandBuilder().setName('pullmember').setDescription('(Premium) Force-pull verified members back.').setDMPermission(false)
        .addIntegerOption(o => o.setName('amount').setDescription('How many to pull (default: all)').setRequired(false)),

    async execute({ interaction }) {
        const { guild, user } = interaction;
        const perm = await isPremiumAuthorized(guild, user.id);
        if (!perm.ok) return interaction.reply({ components: RocksUI.buildStatusMessage('error', perm.reason === 'nopremium' ? 'This server does not have **Premium**.' : 'Only **server owner** or **extra owner** can use this.'), flags: RocksUI.getFlags(true) });

        await interaction.deferReply({ flags: RocksUI.getFlags(true) });
        await guild.members.fetch();
        const currentIds = new Set(guild.members.cache.map(m => m.user.id));
        const verified = await BackupUser.find({ guilds: guild.id, status: 'active' });
        const missing = verified.filter(u => !currentIds.has(u.userId));
        const amount = interaction.options.getInteger('amount') || missing.length;
        const toPull = missing.slice(0, amount);

        if (!toPull.length) return interaction.editReply({ components: RocksUI.buildStatusMessage('tick', 'All verified members are already in the server!'), flags: RocksUI.getFlags() });

        let pulled = 0, failed = 0;
        for (const u of toPull) {
            try {
                const token = await getValidToken(u.userId);
                const status = await forceAddToGuild(guild.id, u.userId, token);
                if (status === 201 || status === 204) pulled++; else failed++;
            } catch { failed++; }
            await sleep(1500);
        }
        return interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} Pull Complete`, null, [{ name: 'Attempted', value: `${toPull.length}` }, { name: 'Pulled', value: `${pulled}` }, { name: 'Failed', value: `${failed}` }]), flags: RocksUI.getFlags() });
    },
};

// ─── /pullablemembers ─────────────────────────────────────────────────────────
export const pullablemembers = {
    data: new SlashCommandBuilder().setName('pullablemembers').setDescription('See verified & pullable member stats.').setDMPermission(false),

    async execute({ interaction }) {
        const { guild, user } = interaction;
        if (!await isAuthorized(guild, user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only **server owner** or **extra owner** can use this.'), flags: RocksUI.getFlags(true) });

        await interaction.deferReply({ flags: RocksUI.getFlags(true) });
        await guild.members.fetch();
        const currentIds = new Set(guild.members.cache.map(m => m.user.id));
        const verified   = await BackupUser.find({ guilds: guild.id, status: 'active' });
        const inServer   = verified.filter(u => currentIds.has(u.userId));
        const pullable   = verified.filter(u => !currentIds.has(u.userId));

        const lines = pullable.slice(0, 15).map((u, i) => `${config.emojis.dot} **${i + 1}.** ${u.username || 'Unknown'} (\`${u.userId}\`)`).join('\n') || `${config.emojis.dot} No pullable members.`;

        return interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.dot} Pullable Members — ${guild.name}`,
            pullable.length > 15 ? `*Showing first 15 of ${pullable.length}*\n\n${lines}` : lines,
            [{ name: 'Server Members', value: `${guild.memberCount}` }, { name: 'Verified', value: `${verified.length}` }, { name: 'In Server', value: `${inServer.length}` }, { name: 'Pullable', value: `${pullable.length}` }]
        ), flags: RocksUI.getFlags() });
    },
};

// ─── /pullmembersimport ───────────────────────────────────────────────────────
export const pullmembersimport = {
    data: new SlashCommandBuilder().setName('pullmembersimport').setDescription('(Premium) Import verified members from one of your servers.').setDMPermission(false)
        .addStringOption(o => o.setName('from_guild').setDescription('Source Guild ID').setRequired(true))
        .addStringOption(o => o.setName('to_guild').setDescription('Destination Guild ID').setRequired(true))
        .addIntegerOption(o => o.setName('amount').setDescription('How many to import').setRequired(false)),

    async execute({ interaction, client }) {
        const { user } = interaction;
        const fromId = interaction.options.getString('from_guild');
        const toId   = interaction.options.getString('to_guild');
        const amount = interaction.options.getInteger('amount') || null;

        const fromGuild = client.guilds.cache.get(fromId);
        const toGuild   = client.guilds.cache.get(toId);

        if (!fromGuild) return interaction.reply({ components: RocksUI.buildStatusMessage('error', `Bot not in source guild \`${fromId}\`.`), flags: RocksUI.getFlags(true) });
        if (!toGuild)   return interaction.reply({ components: RocksUI.buildStatusMessage('error', `Bot not in destination guild \`${toId}\`.`), flags: RocksUI.getFlags(true) });
        if (!await isAuthorized(fromGuild, user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'You are not authorized in the **source** server.'), flags: RocksUI.getFlags(true) });
        if (!await isAuthorized(toGuild, user.id))   return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'You are not authorized in the **destination** server.'), flags: RocksUI.getFlags(true) });
        const perm = await isPremiumAuthorized(toGuild, user.id);
        if (!perm.ok) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Destination server does not have **Premium**.'), flags: RocksUI.getFlags(true) });

        const verified = await BackupUser.find({ guilds: fromId, status: 'active' });
        const toPull   = amount ? verified.slice(0, amount) : verified;

        // Send confirmation to bot owner
        const ownerUser = await client.users.fetch(process.env.OWNER_ID).catch(() => null);
        if (ownerUser) {
            const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = await import('discord.js');
            const container = new ContainerBuilder();
            container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`### ⚠️ Import Request`));
            container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
            container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `${config.emojis.dot} **By:** ${user.username} (\`${user.id}\`)\n` +
                `${config.emojis.dot} **From:** ${fromGuild.name} (\`${fromId}\`)\n` +
                `${config.emojis.dot} **To:** ${toGuild.name} (\`${toId}\`)\n` +
                `${config.emojis.dot} **Members:** ${toPull.length}`
            ));
            container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
            container.addActionRowComponents(new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`import_ok_${fromId}_${toId}_${user.id}_${amount || 'all'}`).setLabel('Approve').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId(`import_no_${user.id}`).setLabel('Deny').setStyle(ButtonStyle.Danger),
            ));
            await ownerUser.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }

        return interaction.reply({ components: RocksUI.buildStatusMessage('tick', 'Import request sent to bot owner for approval.'), flags: RocksUI.getFlags(true) });
    },

    async handleImportButton(interaction, client) {
        if (!isBotOwner(interaction.user.id)) return;
        const { customId } = interaction;

        if (customId.startsWith('import_ok_')) {
            const parts = customId.replace('import_ok_', '').split('_');
            const rawAmt = parts.pop(), requesterId = parts.pop(), toId = parts.pop(), fromId = parts.join('_');
            const amount = rawAmt === 'all' ? null : parseInt(rawAmt);
            await interaction.update({ components: RocksUI.buildStatusMessage('loader', '⏳ Processing import...'), flags: RocksUI.getFlags() });
            const toGuild = client.guilds.cache.get(toId);
            if (!toGuild) return interaction.editReply({ components: RocksUI.buildStatusMessage('error', 'Destination guild not found.'), flags: RocksUI.getFlags() }).catch(() => {});
            const verified = await BackupUser.find({ guilds: fromId, status: 'active' });
            const toPull   = amount ? verified.slice(0, amount) : verified;
            let pulled = 0, failed = 0;
            for (const u of toPull) {
                try { const token = await getValidToken(u.userId); const s = await forceAddToGuild(toId, u.userId, token); if (s === 201 || s === 204) pulled++; else failed++; } catch { failed++; }
                await sleep(1500);
            }
            await interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} Import Done`, null, [{ name: 'Pulled', value: `${pulled}` }, { name: 'Failed', value: `${failed}` }]), flags: RocksUI.getFlags() }).catch(() => {});
            try { const ru = await client.users.fetch(requesterId); await ru.send({ components: RocksUI.buildStatusMessage('tick', `Import approved. **${pulled}** members added.`), flags: RocksUI.getFlags() }); } catch { /* DMs closed */ }
        }

        if (customId.startsWith('import_no_')) {
            const requesterId = customId.replace('import_no_', '');
            await interaction.update({ components: RocksUI.buildStatusMessage('error', 'Import denied.'), flags: RocksUI.getFlags() });
            try { const ru = await client.users.fetch(requesterId); await ru.send({ components: RocksUI.buildStatusMessage('error', 'Your import request was **denied**.'), flags: RocksUI.getFlags() }); } catch { /* DMs closed */ }
        }
    },
};
