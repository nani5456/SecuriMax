import {
    SlashCommandBuilder, ChannelType, PermissionFlagsBits,
    ActionRowBuilder, ButtonBuilder, ButtonStyle,
    ContainerBuilder, TextDisplayBuilder, SeparatorBuilder,
    SeparatorSpacingSize, MessageFlags,
} from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import { isAuthorized, getOrCreateConfig } from '../../utils/permCheck.js';
import GuildConfig from '../../database/schemas/GuildConfig.js';
import { buildOAuthURL } from '../../server/oauth.js';

// ─── Post the verify panel with a button (no visible URL) ────────────────────
export async function postVerifyPanel(channel, guildId) {
    const container = new ContainerBuilder();
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `### ${config.emojis.vip} Server Verification Required`
    ));
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `${config.emojis.dot} Welcome! This server requires you to verify before gaining access.\n` +
        `${config.emojis.dot} Click the button below to get your personal verification link.\n` +
        `${config.emojis.dot} Verification only takes a few seconds.`
    ));
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
    container.addActionRowComponents(
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`verify_btn_${guildId}`)
                .setLabel('🔐 Verify')
                .setStyle(ButtonStyle.Success)
        )
    );
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));

    return channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
}

// ─── Handle verify button click ──────────────────────────────────────────────
export async function handleVerifyButton(interaction) {
    const { guild, user } = interaction;

    // Check if already verified (doesn't have unverified role)
    const cfg = await GuildConfig.findOne({ guildId: guild.id });
    if (cfg?.verify?.unverifiedRoleId) {
        const member = await guild.members.fetch(user.id).catch(() => null);
        if (member && !member.roles.cache.has(cfg.verify.unverifiedRoleId)) {
            return interaction.reply({
                components: RocksUI.buildStatusMessage('tick', 'You are already verified!'),
                flags: RocksUI.getFlags(true),
            });
        }
    }

    // Generate personal OAuth2 URL
    const url = `${process.env.REDIRECT_URI.replace('/callback', '')}/verify?guild=${guild.id}&user=${user.id}`;

    const container = new ContainerBuilder();
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `### ${config.emojis.vip} Your Personal Verification Link`
    ));
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `${config.emojis.dot} Click the button below to verify your account.\n` +
        `${config.emojis.dot} This link is personal and only works for you.\n` +
        `${config.emojis.dot} You'll be redirected back automatically after verifying.`
    ));
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
    container.addActionRowComponents(
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel('🔐 Open Verification Page')
                .setStyle(ButtonStyle.Link)
                .setURL(url)
        )
    );
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));

    return interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
    });
}

// ─── DM a user their verify link ─────────────────────────────────────────────
export async function sendVerifyDM(user, guildId, guildName) {
    try {
        const url = `${process.env.REDIRECT_URI.replace('/callback', '')}/verify?guild=${guildId}&user=${user.id}`;
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `### ${config.emojis.vip} Verify in **${guildName}**`
        ));
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `${config.emojis.dot} You joined **${guildName}** and need to verify to get access.\n` +
            `${config.emojis.dot} Click the button below — only takes 2 seconds.`
        ));
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
        container.addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setLabel('🔐 Verify Now').setStyle(ButtonStyle.Link).setURL(url)
            )
        );
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
        await user.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        return true;
    } catch { return false; }
}

// ─── Setup verification system ────────────────────────────────────────────────
export default {
    data: new SlashCommandBuilder()
        .setName('setupverify')
        .setDescription('Manage the verification gate.')
        .setDMPermission(false)
        .addSubcommand(s => s.setName('enable').setDescription('Enable verification and create #verify channel.'))
        .addSubcommand(s => s.setName('disable').setDescription('Disable verification gate.'))
        .addSubcommand(s => s.setName('dmall').setDescription('DM all unverified members their verify link.')),

    async execute({ interaction, client }) {
        const { guild, user } = interaction;
        if (!await isAuthorized(guild, user.id)) {
            return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only **server owner** or **extra owner** can use this.'), flags: RocksUI.getFlags(true) });
        }

        const sub = interaction.options.getSubcommand();

        if (sub === 'enable') {
            await interaction.deferReply({ flags: RocksUI.getFlags(true) });

            // Create Unverified role
            let unverifiedRole = guild.roles.cache.find(r => r.name === 'Unverified');
            if (!unverifiedRole) unverifiedRole = await guild.roles.create({ name: 'Unverified', color: '#99aab5', permissions: [] });

            // Create Member role
            let memberRole = guild.roles.cache.find(r => r.name === 'Member');
            if (!memberRole) memberRole = await guild.roles.create({ name: 'Member', color: '#57f287' });

            // Lock all channels from Unverified
            for (const [, ch] of guild.channels.cache) {
                await ch.permissionOverwrites.edit(unverifiedRole, { ViewChannel: false, SendMessages: false }).catch(() => {});
            }

            // Create or find #verify channel
            let verifyChannel = guild.channels.cache.find(c => c.name === 'verify' && c.type === ChannelType.GuildText);
            if (!verifyChannel) {
                verifyChannel = await guild.channels.create({
                    name: 'verify', type: ChannelType.GuildText,
                    permissionOverwrites: [
                        { id: guild.id,                deny: [PermissionFlagsBits.ViewChannel] },
                        { id: unverifiedRole.id,       allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory], deny: [PermissionFlagsBits.SendMessages] },
                        { id: guild.members.me.id,     allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageMessages] },
                    ],
                });
            }

            // Clear old messages and post the verify panel (button only, no link)
            await verifyChannel.bulkDelete(10).catch(() => {});
            const panelMsg = await postVerifyPanel(verifyChannel, guild.id);

            // Save config
            await GuildConfig.findOneAndUpdate(
                { guildId: guild.id },
                {
                    'verify.enabled':         true,
                    'verify.channelId':        verifyChannel.id,
                    'verify.messageId':        panelMsg.id,
                    'verify.unverifiedRoleId': unverifiedRole.id,
                    'verify.memberRoleId':     memberRole.id,
                },
                { upsert: true }
            );

            return interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} Verification Enabled`, null, [
                { name: 'Verify Channel', value: `<#${verifyChannel.id}>` },
                { name: 'Unverified Role', value: `<@&${unverifiedRole.id}>` },
                { name: 'Member Role', value: `<@&${memberRole.id}>` },
                { name: 'How it works', value: 'New members get Unverified role → see only #verify → click Verify button → get personal link → gain access.' },
            ]), flags: RocksUI.getFlags() });
        }

        if (sub === 'disable') {
            await GuildConfig.findOneAndUpdate({ guildId: guild.id }, { 'verify.enabled': false }, { upsert: true });
            return interaction.reply({ components: RocksUI.buildStatusMessage('tick', 'Verification gate **disabled**.'), flags: RocksUI.getFlags(true) });
        }

        if (sub === 'dmall') {
            await interaction.deferReply({ flags: RocksUI.getFlags(true) });
            await guild.members.fetch();
            const cfg       = await GuildConfig.findOne({ guildId: guild.id });
            const roleId    = cfg?.verify?.unverifiedRoleId;
            const targets   = guild.members.cache.filter(m => !m.user.bot && (roleId ? m.roles.cache.has(roleId) : true));
            let sent = 0, failed = 0;
            for (const [, m] of targets) {
                const ok = await sendVerifyDM(m.user, guild.id, guild.name);
                if (ok) sent++; else failed++;
                await new Promise(r => setTimeout(r, 400));
            }
            return interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} DMs Sent`, null, [{ name: 'Sent', value: `${sent}` }, { name: 'Failed (DMs closed)', value: `${failed}` }]), flags: RocksUI.getFlags() });
        }
    },
};
