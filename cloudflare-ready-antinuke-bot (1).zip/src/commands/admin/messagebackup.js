import { SlashCommandBuilder, ChannelType, WebhookClient } from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import { isPremiumAuthorized } from '../../utils/permCheck.js';
import MessageBackup from '../../database/schemas/MessageBackup.js';
import { snapshotRoles, snapshotChannels, restoreRoles, restoreChannels } from './backup.js';
import { randomUUID } from 'crypto';

const MAX = 10000;

async function fetchMsgs(channel) {
    const msgs = []; let lastId = null;
    while (msgs.length < MAX) {
        const batch = await channel.messages.fetch({ limit: 100, ...(lastId ? { before: lastId } : {}) }).catch(() => null);
        if (!batch?.size) break;
        batch.forEach(m => {
            if (msgs.length >= MAX) return;
            msgs.push({
                authorId: m.author.id, authorName: m.author.username,
                authorAvatar: m.author.avatar ? `https://cdn.discordapp.com/avatars/${m.author.id}/${m.author.avatar}.png?size=128` : `https://cdn.discordapp.com/embed/avatars/${Number(BigInt(m.author.id) >> 22n) % 6}.png`,
                content: m.content || null, attachments: m.attachments.map(a => a.url), createdAt: m.createdAt.toISOString(),
            });
        });
        lastId = batch.last()?.id;
        if (batch.size < 100) break;
        await new Promise(r => setTimeout(r, 800));
    }
    return msgs.reverse();
}

export default {
    data: new SlashCommandBuilder().setName('messagebackup').setDescription('(Premium) Backup and restore messages.').setDMPermission(false)
        .addSubcommand(s => s.setName('create').setDescription('Backup up to 10k messages per channel.'))
        .addSubcommand(s => s.setName('list').setDescription('List message backups.'))
        .addSubcommand(s => s.setName('restore').setDescription('Restore a message backup.').addStringOption(o => o.setName('id').setDescription('Backup ID').setRequired(true))),

    async execute({ interaction, client }) {
        const { guild, user } = interaction;
        const perm = await isPremiumAuthorized(guild, user.id);
        if (!perm.ok) {
            return interaction.reply({ components: RocksUI.buildStatusMessage('error', perm.reason === 'nopremium' ? 'This server does not have **Premium**.' : 'Only **server owner** or **extra owner** can use this.'), flags: RocksUI.getFlags(true) });
        }

        const sub = interaction.options.getSubcommand();

        if (sub === 'create') {
            await interaction.deferReply({ flags: RocksUI.getFlags(true) });
            const chs = guild.channels.cache.filter(c => c.type === ChannelType.GuildText && c.permissionsFor(guild.members.me)?.has('ReadMessageHistory'));
            await interaction.editReply({ components: RocksUI.buildStatusMessage('loader', `⏳ Collecting from **${chs.size}** channels...`), flags: RocksUI.getFlags() });
            const channelMessages = {}; let total = 0;
            for (const [, ch] of chs) {
                const msgs = await fetchMsgs(ch);
                channelMessages[ch.id] = { channelName: ch.name, messages: msgs };
                total += msgs.length;
            }
            const id = randomUUID().slice(0, 8).toUpperCase();
            await MessageBackup.create({ backupId: id, guildId: guild.id, guildName: guild.name, channelCount: chs.size, totalMessages: total, structure: { roles: snapshotRoles(guild), ...snapshotChannels(guild) }, channelMessages });
            return interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} Message Backup Created`, null, [{ name: 'ID', value: `\`${id}\`` }, { name: 'Channels', value: `${chs.size}` }, { name: 'Messages', value: `${total.toLocaleString()}` }, { name: 'Created', value: `<t:${Math.floor(Date.now() / 1000)}:F>` }]), flags: RocksUI.getFlags() });
        }

        if (sub === 'list') {
            const bs = await MessageBackup.find({ guildId: guild.id }).sort({ createdAt: -1 });
            if (!bs.length) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'No message backups found.'), flags: RocksUI.getFlags(true) });
            const lines = bs.map(b => `${config.emojis.dot} **\`${b.backupId}\`** · ${b.channelCount}ch · ${(b.totalMessages || 0).toLocaleString()} msgs · <t:${Math.floor(b.createdAt.getTime() / 1000)}:R>`).join('\n');
            return interaction.reply({ components: RocksUI.buildDashboard(`# ${config.emojis.dot} Message Backups — ${guild.name}`, lines), flags: RocksUI.getFlags(true) });
        }

        if (sub === 'restore') {
            const id = interaction.options.getString('id').toUpperCase();
            const backup = await MessageBackup.findOne({ backupId: id, guildId: guild.id });
            if (!backup) return interaction.reply({ components: RocksUI.buildStatusMessage('error', `No backup with ID \`${id}\`.`), flags: RocksUI.getFlags(true) });
            await interaction.deferReply({ flags: RocksUI.getFlags(true) });
            await interaction.editReply({ components: RocksUI.buildStatusMessage('loader', '⏳ Rebuilding structure...'), flags: RocksUI.getFlags() });
            const roleMap = await restoreRoles(guild, backup.structure.roles);
            await restoreChannels(guild, { categories: backup.structure.categories, channels: backup.structure.channels }, roleMap);
            await interaction.editReply({ components: RocksUI.buildStatusMessage('loader', '⏳ Replaying messages...'), flags: RocksUI.getFlags() });
            let totalSent = 0;
            for (const [, data] of Object.entries(backup.channelMessages)) {
                const target = guild.channels.cache.find(c => c.type === ChannelType.GuildText && c.name === data.channelName);
                if (!target) continue;
                let wh = null;
                try { wh = await target.createWebhook({ name: 'Restore', avatarURL: client.user.displayAvatarURL(), reason: '[MessageBackup]' }); } catch { continue; }
                const wc = new WebhookClient({ id: wh.id, token: wh.token });
                for (const msg of data.messages) {
                    if (!msg.content && !msg.attachments?.length) continue;
                    try { await wc.send({ content: msg.content || undefined, username: msg.authorName, avatarURL: msg.authorAvatar, allowedMentions: { parse: [] } }); totalSent++; } catch { /* skip */ }
                    await new Promise(r => setTimeout(r, 120));
                }
                await wc.destroy(); await wh.delete('[MessageBackup]').catch(() => {});
            }
            return interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} Restore Complete`, null, [{ name: 'Backup ID', value: `\`${id}\`` }, { name: 'Messages Restored', value: `${totalSent.toLocaleString()}` }]), flags: RocksUI.getFlags() });
        }
    },
};
