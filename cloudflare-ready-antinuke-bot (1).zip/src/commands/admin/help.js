import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import { isAuthorized } from '../../utils/permCheck.js';

const CATEGORIES = {
    antinuke: {
        label: '🛡️ AntiNuke',
        content: [
            `${config.emojis.arrow} \`/antinuke\` — Open the antinuke panel with 1-click module management`,
        ],
    },
    verify: {
        label: '✅ Verification',
        content: [
            `${config.emojis.arrow} \`/setupverify enable\` — Set up verification gate with button panel`,
            `${config.emojis.arrow} \`/setupverify disable\` — Disable verification`,
            `${config.emojis.arrow} \`/setupverify dmall\` — DM all unverified members`,
        ],
    },
    backup: {
        label: '💾 Backup',
        content: [
            `${config.emojis.arrow} \`/backup create\` — Snapshot roles, channels & categories`,
            `${config.emojis.arrow} \`/backup list\` — List all server backups`,
            `${config.emojis.arrow} \`/backup restore <id> <scope>\` — Restore a backup`,
            `${config.emojis.arrow} \`/backup delete <id>\` — Delete a backup`,
        ],
    },
    premium: {
        label: '✨ Premium',
        content: [
            `${config.emojis.arrow} \`/messagebackup create\` — Backup 10k messages per channel`,
            `${config.emojis.arrow} \`/messagebackup list\` — List message backups`,
            `${config.emojis.arrow} \`/messagebackup restore <id>\` — Rebuild server + replay messages`,
            `${config.emojis.arrow} \`/pullmember [amount]\` — Force-pull verified members back`,
            `${config.emojis.arrow} \`/pullablemembers\` — See verified & pullable stats`,
            `${config.emojis.arrow} \`/pullmembersimport <from> <to> [amount]\` — Import members across your servers`,
        ],
    },
    tickets: {
        label: '🎫 Tickets',
        content: [
            `${config.emojis.arrow} \`/fullsetup wizard\` — Run the ticket system setup wizard`,
            `${config.emojis.arrow} \`/panel\` — Post the ticket panel in a channel`,
            `${config.emojis.arrow} \`/ticketclose\` — Close the current ticket`,
            `${config.emojis.arrow} \`/ticketadd <user>\` — Add a user to the ticket`,
            `${config.emojis.arrow} \`/rename <name>\` — Rename the ticket channel`,
        ],
    },
    admin: {
        label: '👑 Admin',
        content: [
            `${config.emojis.arrow} \`/extraowner add/remove/list\` — Manage extra owners *(server owner only)*`,
            `${config.emojis.arrow} \`/ping\` — Check bot latency`,
        ],
    },
};

function buildCategoryRow(active = null) {
    const keys = Object.keys(CATEGORIES);
    const rows = [];
    // Split into rows of 5
    for (let i = 0; i < keys.length; i += 5) {
        const row = new ActionRowBuilder().addComponents(
            keys.slice(i, i + 5).map(k =>
                new ButtonBuilder()
                    .setCustomId(`help_cat_${k}`)
                    .setLabel(CATEGORIES[k].label)
                    .setStyle(k === active ? ButtonStyle.Primary : ButtonStyle.Secondary)
            )
        );
        rows.push(row);
    }
    return rows;
}

export default {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Interactive help panel.')
        .setDMPermission(false),

    async execute({ interaction }) {
        const { guild, user } = interaction;
        if (!await isAuthorized(guild, user.id)) {
            return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only **server owner** or **extra owner** can use this.'), flags: RocksUI.getFlags(true) });
        }

        const desc =
            `${config.emojis.vip} Welcome to the help panel!\n\n` +
            `${config.emojis.dot} Select a category below to see all commands.\n` +
            `${config.emojis.dot} Only server owner and extra owners can use most commands.`;

        const rows = buildCategoryRow();
        return interaction.reply({
            components: RocksUI.buildDashboard(`# ${config.emojis.dot} Help Panel`, desc, rows),
            flags: RocksUI.getFlags(true),
        });
    },

    async handleButton(interaction) {
        const { customId } = interaction;
        const key = customId.replace('help_cat_', '');
        const cat = CATEGORIES[key];
        if (!cat) return;

        const desc = cat.content.join('\n');
        const rows = buildCategoryRow(key);

        return interaction.update({
            components: RocksUI.buildDashboard(`# ${config.emojis.dot} Help — ${cat.label}`, desc, rows),
            flags: RocksUI.getFlags(),
        });
    },
};
