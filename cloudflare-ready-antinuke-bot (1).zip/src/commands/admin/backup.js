import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } from 'discord.js';
import { RocksUI } from '../../structures/classes/RocksUI.js';
import { config } from '../../config/config.js';
import { isAuthorized } from '../../utils/permCheck.js';
import ServerBackup from '../../database/schemas/ServerBackup.js';
import { randomUUID } from 'crypto';

export function snapshotRoles(guild) {
    return guild.roles.cache.filter(r => r.id !== guild.id && !r.managed).sort((a, b) => b.position - a.position)
        .map(r => ({ id: r.id, name: r.name, color: r.hexColor, hoist: r.hoist, mentionable: r.mentionable, permissions: r.permissions.bitfield.toString(), position: r.position }));
}

export function snapshotChannels(guild) {
    const categories = [], channels = [];
    guild.channels.cache.forEach(ch => {
        const ow = ch.permissionOverwrites?.cache.map(o => ({ id: o.id, type: o.type, allow: o.allow.bitfield.toString(), deny: o.deny.bitfield.toString() })) || [];
        if (ch.type === ChannelType.GuildCategory) categories.push({ id: ch.id, name: ch.name, position: ch.position, permissionOverwrites: ow });
        else channels.push({ id: ch.id, name: ch.name, type: ch.type, parentId: ch.parentId || null, position: ch.position, topic: ch.topic || null, nsfw: ch.nsfw || false, rateLimitPerUser: ch.rateLimitPerUser || 0, userLimit: ch.userLimit || 0, bitrate: ch.bitrate || null, permissionOverwrites: ow });
    });
    return { categories, channels };
}

export async function restoreRoles(guild, snapshot) {
    for (const [, r] of guild.roles.cache.filter(r => r.id !== guild.id && !r.managed && r.editable)) await r.delete('[Backup]').catch(() => {});
    const map = {};
    for (const r of [...snapshot].reverse()) {
        try { const c = await guild.roles.create({ name: r.name, color: r.color, hoist: r.hoist, mentionable: r.mentionable, permissions: BigInt(r.permissions), reason: '[Backup]' }); map[r.id] = c.id; } catch { /* skip */ }
    }
    return map;
}

export async function restoreChannels(guild, { categories, channels }, roleMap = {}) {
    for (const [, ch] of guild.channels.cache) await ch.delete('[Backup]').catch(() => {});
    const resolve = id => roleMap[id] || id;
    const catMap = {};
    for (const cat of categories) {
        try { const c = await guild.channels.create({ name: cat.name, type: ChannelType.GuildCategory, permissionOverwrites: cat.permissionOverwrites.map(o => ({ id: resolve(o.id), type: o.type, allow: BigInt(o.allow), deny: BigInt(o.deny) })), reason: '[Backup]' }); catMap[cat.id] = c.id; } catch { /* skip */ }
    }
    for (const ch of channels) {
        try {
            const opts = { name: ch.name, type: ch.type, parent: ch.parentId ? catMap[ch.parentId] || null : null, topic: ch.topic || undefined, nsfw: ch.nsfw, rateLimitPerUser: ch.rateLimitPerUser, permissionOverwrites: ch.permissionOverwrites.map(o => ({ id: resolve(o.id), type: o.type, allow: BigInt(o.allow), deny: BigInt(o.deny) })), reason: '[Backup]' };
            if (ch.type === ChannelType.GuildVoice) { opts.userLimit = ch.userLimit; opts.bitrate = ch.bitrate; }
            await guild.channels.create(opts);
        } catch { /* skip */ }
    }
}

export default {
    data: new SlashCommandBuilder().setName('backup').setDescription('Server backup management.').setDMPermission(false)
        .addSubcommand(s => s.setName('create').setDescription('Create a server backup.'))
        .addSubcommand(s => s.setName('list').setDescription('List all backups.'))
        .addSubcommand(s => s.setName('restore').setDescription('Restore a backup.')
            .addStringOption(o => o.setName('id').setDescription('Backup ID').setRequired(true))
            .addStringOption(o => o.setName('scope').setDescription('What to restore').setRequired(true)
                .addChoices({ name: 'All', value: 'all' }, { name: 'Roles only', value: 'roles' }, { name: 'Channels only', value: 'channels' })))
        .addSubcommand(s => s.setName('delete').setDescription('Delete a backup.').addStringOption(o => o.setName('id').setDescription('Backup ID').setRequired(true))),

    async execute({ interaction }) {
        const { guild, user } = interaction;
        if (!await isAuthorized(guild, user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Only **server owner** or **extra owner** can use backups.'), flags: RocksUI.getFlags(true) });

        const sub = interaction.options.getSubcommand();

        if (sub === 'create') {
            await interaction.deferReply({ flags: RocksUI.getFlags(true) });
            const roles = snapshotRoles(guild);
            const { categories, channels } = snapshotChannels(guild);
            const id = randomUUID().slice(0, 8).toUpperCase();
            await ServerBackup.create({ backupId: id, guildId: guild.id, guildName: guild.name, roleCount: roles.length, channelCount: channels.length, categoryCount: categories.length, data: { roles, categories, channels } });
            return interaction.editReply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.tick} Backup Created`, null, [{ name: 'ID', value: `\`${id}\`` }, { name: 'Roles', value: `${roles.length}` }, { name: 'Categories', value: `${categories.length}` }, { name: 'Channels', value: `${channels.length}` }, { name: 'Created', value: `<t:${Math.floor(Date.now() / 1000)}:F>` }]), flags: RocksUI.getFlags() });
        }

        if (sub === 'list') {
            const bs = await ServerBackup.find({ guildId: guild.id }).sort({ createdAt: -1 });
            if (!bs.length) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'No backups found.'), flags: RocksUI.getFlags(true) });
            const lines = bs.map(b => `${config.emojis.dot} **\`${b.backupId}\`** · ${b.roleCount}r ${b.categoryCount}cat ${b.channelCount}ch · <t:${Math.floor(b.createdAt.getTime() / 1000)}:R>`).join('\n');
            return interaction.reply({ components: RocksUI.buildDashboard(`# ${config.emojis.dot} Backups — ${guild.name}`, lines), flags: RocksUI.getFlags(true) });
        }

        if (sub === 'restore') {
            const id = interaction.options.getString('id').toUpperCase();
            const scope = interaction.options.getString('scope');
            const backup = await ServerBackup.findOne({ backupId: id, guildId: guild.id });
            if (!backup) return interaction.reply({ components: RocksUI.buildStatusMessage('error', `No backup with ID \`${id}\`.`), flags: RocksUI.getFlags(true) });
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`bk_confirm_${id}_${scope}`).setLabel('Confirm Restore').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('bk_cancel').setLabel('Cancel').setStyle(ButtonStyle.Secondary),
            );
            return interaction.reply({ components: RocksUI.buildDetailedDashboard(`# ${config.emojis.error} Confirm Restore`, `⚠️ This will delete all current ${scope} and replace with backup. Cannot be undone.`, [{ name: 'Backup ID', value: `\`${id}\`` }, { name: 'Scope', value: scope }, { name: 'Backed up', value: `<t:${Math.floor(backup.createdAt.getTime() / 1000)}:R>` }], [row]), flags: RocksUI.getFlags(true) });
        }

        if (sub === 'delete') {
            const id = interaction.options.getString('id').toUpperCase();
            const res = await ServerBackup.deleteOne({ backupId: id, guildId: guild.id });
            if (!res.deletedCount) return interaction.reply({ components: RocksUI.buildStatusMessage('error', `No backup with ID \`${id}\`.`), flags: RocksUI.getFlags(true) });
            return interaction.reply({ components: RocksUI.buildStatusMessage('tick', `Backup \`${id}\` deleted.`), flags: RocksUI.getFlags(true) });
        }
    },

    async handleButton(interaction) {
        const { guild, user, customId } = interaction;
        if (!await isAuthorized(guild, user.id)) return interaction.reply({ components: RocksUI.buildStatusMessage('error', 'Not authorized.'), flags: RocksUI.getFlags(true) });
        if (customId === 'bk_cancel') return interaction.update({ components: RocksUI.buildStatusMessage('dot', 'Restore cancelled.'), flags: RocksUI.getFlags() });
        if (customId.startsWith('bk_confirm_')) {
            const parts = customId.replace('bk_confirm_', '').split('_');
            const scope = parts.pop(), id = parts.join('_');
            const backup = await ServerBackup.findOne({ backupId: id, guildId: guild.id });
            if (!backup) return interaction.update({ components: RocksUI.buildStatusMessage('error', 'Backup not found.'), flags: RocksUI.getFlags() });
            await interaction.update({ components: RocksUI.buildStatusMessage('loader', '⏳ Restoring...'), flags: RocksUI.getFlags() });
            try {
                let roleMap = {};
                if (scope === 'all' || scope === 'roles')    roleMap = await restoreRoles(guild, backup.data.roles);
                if (scope === 'all' || scope === 'channels') await restoreChannels(guild, { categories: backup.data.categories, channels: backup.data.channels }, roleMap);
                await interaction.editReply({ components: RocksUI.buildStatusMessage('tick', `Backup \`${id}\` restored.`), flags: RocksUI.getFlags() }).catch(() => {});
            } catch (err) {
                await interaction.editReply({ components: RocksUI.buildStatusMessage('error', `Restore failed: ${err.message}`), flags: RocksUI.getFlags() }).catch(() => {});
            }
        }
    },
};
