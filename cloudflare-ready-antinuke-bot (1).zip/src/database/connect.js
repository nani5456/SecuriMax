import mongoose from 'mongoose';
import chalk from 'chalk';

export const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log(chalk.green('[DB] Connected to MongoDB.'));
    } catch (err) {
        console.error(chalk.red('[DB] Connection failed:'), err.message);
        process.exit(1);
    }
};
