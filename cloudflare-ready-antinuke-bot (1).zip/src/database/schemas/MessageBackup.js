import { Schema, model } from 'mongoose';

const messageBackupSchema = new Schema({
    backupId:      { type: String, required: true },
    guildId:       { type: String, required: true },
    guildName:     { type: String },
    channelCount:  { type: Number, default: 0 },
    totalMessages: { type: Number, default: 0 },
    structure: { type: Schema.Types.Mixed, default: {} },
    channelMessages: { type: Schema.Types.Mixed, default: {} },
}, { timestamps: true });

export default model('MessageBackup', messageBackupSchema);
