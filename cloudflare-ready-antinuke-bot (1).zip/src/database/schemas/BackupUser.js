import { Schema, model } from 'mongoose';

const backupUserSchema = new Schema({
    userId:       { type: String, required: true, unique: true },
    username:     { type: String, default: null },
    avatar:       { type: String, default: null },
    accessToken:  { type: String, required: true },
    refreshToken: { type: String, required: true },
    expiresAt:    { type: Number, required: true },
    guilds:       { type: [String], default: [] },
    status:       { type: String, enum: ['active', 'inactive'], default: 'active' },
}, { timestamps: true });

export default model('BackupUser', backupUserSchema);
