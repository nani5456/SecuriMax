import { Schema, model } from 'mongoose';

const serverBackupSchema = new Schema({
    backupId:      { type: String, required: true },
    guildId:       { type: String, required: true },
    guildName:     { type: String },
    roleCount:     { type: Number, default: 0 },
    channelCount:  { type: Number, default: 0 },
    categoryCount: { type: Number, default: 0 },
    data: {
        roles:      { type: Schema.Types.Mixed, default: [] },
        categories: { type: Schema.Types.Mixed, default: [] },
        channels:   { type: Schema.Types.Mixed, default: [] },
    },
}, { timestamps: true });

export default model('ServerBackup', serverBackupSchema);
