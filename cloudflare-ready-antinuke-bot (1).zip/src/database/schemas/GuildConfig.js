import { Schema, model } from 'mongoose';

const antinukeSchema = new Schema({
    antiBan: { type: Boolean, default: false },
    antiUnban: { type: Boolean, default: false },
    antiKick: { type: Boolean, default: false },
    antiBotAdd: { type: Boolean, default: false },
    antiChannelCreate: { type: Boolean, default: false },
    antiChannelDelete: { type: Boolean, default: false },
    antiChannelUpdate: { type: Boolean, default: false },
    antiRoleCreate: { type: Boolean, default: false },
    antiRoleDelete: { type: Boolean, default: false },
    antiRoleUpdate: { type: Boolean, default: false },
    antiMemberUpdate: { type: Boolean, default: false },
    antiEmojiCreate: { type: Boolean, default: false },
    antiEmojiDelete: { type: Boolean, default: false },
    antiEmojiUpdate: { type: Boolean, default: false },
    antiEveryonePing: { type: Boolean, default: false },
    antiRolePing: { type: Boolean, default: false },
    antiIntegration: { type: Boolean, default: false },
    antiGuildUpdate: { type: Boolean, default: false },
    antiWebhookCreate: { type: Boolean, default: false },
    antiWebhookDelete: { type: Boolean, default: false },
    antiWebhookUpdate: { type: Boolean, default: false },
    antiLinkRole: { type: Boolean, default: false },
    antiInviteRole: { type: Boolean, default: false },
    autoRecovery: { type: Boolean, default: false },
}, { _id: false });

const verifySchema = new Schema({
    enabled: { type: Boolean, default: false },
    channelId: { type: String, default: null },
    messageId: { type: String, default: null },
    unverifiedRoleId: { type: String, default: null },
    memberRoleId: { type: String, default: null },
}, { _id: false });

const ticketSchema = new Schema({
    enabled: { type: Boolean, default: false },
    mmCategoryId: { type: String, default: null },
    supportCategoryId: { type: String, default: null },
    mmStaffRoles: { type: [String], default: [] },
    supportStaffRoles: { type: [String], default: [] },
    ticketLogChannel: { type: String, default: null },
    hitLogChannel: { type: String, default: null },
    ontopRole: { type: String, default: null },
}, { _id: false });

const guildConfigSchema = new Schema({
    guildId:     { type: String, required: true, unique: true },
    extraOwners: { type: [String], default: [] },
    isPremium:   { type: Boolean, default: false },
    antinuke:    { type: antinukeSchema, default: () => ({}) },
    verify:      { type: verifySchema, default: () => ({}) },
    tickets:     { type: ticketSchema, default: () => ({}) },
}, { timestamps: true });

export default model('GuildConfig', guildConfigSchema);
