import { Schema, model } from 'mongoose';

const ticketSchema = new Schema({
    guildId:   { type: String, required: true },
    channelId: { type: String, required: true, unique: true },
    userId:    { type: String, required: true },
    username:  { type: String, default: null },
    type:      { type: String, enum: ['middleman', 'support'], default: 'support' },
    status:    { type: String, enum: ['open', 'closed'], default: 'open' },
    claimedBy: { type: String, default: null },
    ticketNumber: { type: Number, default: 0 },
}, { timestamps: true });

export default model('Ticket', ticketSchema);
