import chalk from 'chalk';
import GuildConfig from '../database/schemas/GuildConfig.js';
import { sendVerifyDM } from '../commands/admin/setupverify.js';
import * as engine from '../utils/antinukeEngine.js';

export const channelCache = new Map();

export default [
    {
        name: 'ready',
        once: true,
        execute(client) {
            console.log(chalk.green(`[BOT] Logged in as ${client.user.tag}`));
            console.log(chalk.cyan(`[BOT] ${client.guilds.cache.size} guilds`));
            client.user.setActivity('🛡️ AntiNuke Protection');
        },
    },
    {
        name: 'guildCreate',
        async execute(guild) {
            const cfg = await GuildConfig.findOne({ guildId: guild.id });
            if (cfg?.blacklisted) {
                console.log(chalk.yellow(`[BLACKLIST] Left ${guild.name}`));
                return guild.leave().catch(() => {});
            }
            console.log(chalk.blue(`[GUILD] Joined: ${guild.name}`));
        },
    },
    {
        name: 'guildMemberAdd',
        async execute(member) {
            await engine.handleBotAdd(member.guild, member);
            if (member.user.bot) return;

            const cfg = await GuildConfig.findOne({ guildId: member.guild.id });
            if (cfg?.verify?.enabled && cfg?.verify?.unverifiedRoleId) {
                await member.roles.add(cfg.verify.unverifiedRoleId).catch(() => {});
                await sendVerifyDM(member.user, member.guild.id, member.guild.name);
            }
        },
    },
    { name: 'guildBanAdd',    async execute(ban)              { await engine.handleBan(ban.guild, ban.user); } },
    { name: 'guildBanRemove', async execute(ban)              { await engine.handleUnban(ban.guild, ban.user); } },
    { name: 'guildMemberRemove', async execute(member)        { await engine.handleKick(member.guild, member); } },
    {
        name: 'channelCreate',
        async execute(channel) {
            if (!channel.guild) return;
            await engine.handleChannelCreate(channel.guild, channel);
        },
    },
    {
        name: 'channelDelete',
        async execute(channel) {
            if (!channel.guild) return;
            const cached = channelCache.get(channel.id) || channel;
            await engine.handleChannelDelete(channel.guild, cached);
            channelCache.delete(channel.id);
        },
    },
    {
        name: 'channelUpdate',
        async execute(old, cur) {
            if (!cur.guild) return;
            channelCache.set(cur.id, old);
            await engine.handleChannelUpdate(cur.guild, old, cur);
        },
    },
    { name: 'roleCreate',  async execute(role)              { await engine.handleRoleCreate(role.guild, role); } },
    { name: 'roleDelete',  async execute(role)              { await engine.handleRoleDelete(role.guild, role); } },
    { name: 'roleUpdate',  async execute(old, cur)          { await engine.handleRoleUpdate(cur.guild, old, cur); } },
    { name: 'guildMemberUpdate', async execute(old, cur)    { await engine.handleMemberUpdate(cur.guild, old, cur); } },
    { name: 'emojiCreate', async execute(emoji)             { await engine.handleEmojiCreate(emoji.guild, emoji); } },
    { name: 'emojiDelete', async execute(emoji)             { await engine.handleEmojiDelete(emoji.guild, emoji); } },
    { name: 'emojiUpdate', async execute(old, cur)          { await engine.handleEmojiUpdate(cur.guild, old, cur); } },
    { name: 'guildUpdate', async execute(old, cur)          { await engine.handleGuildUpdate(cur, old, cur); } },
    {
        name: 'webhookUpdate',
        async execute(channel) {
            if (!channel.guild) return;
            await engine.handleWebhookCreate(channel.guild);
            await engine.handleWebhookDelete(channel.guild);
            await engine.handleWebhookUpdate(channel.guild);
        },
    },
    { name: 'guildIntegrationsUpdate', async execute(guild) { await engine.handleIntegration(guild); } },
    {
        name: 'messageCreate',
        async execute(message) {
            if (!message.guild || message.author.bot) return;
            await engine.handleEveryonePing(message);
            await engine.handleRolePing(message);
            await engine.handleLinkRole(message);
            await engine.handleInviteRole(message);
        },
    },
];
