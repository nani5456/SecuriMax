import { RocksUI } from '../structures/classes/RocksUI.js';
import GuildConfig from '../database/schemas/GuildConfig.js';
import antinukeCmd   from '../commands/admin/antinuke.js';
import backupCmd     from '../commands/admin/backup.js';
import helpCmd       from '../commands/admin/help.js';
import panelCmd      from '../commands/tickets/panel.js';
import ticketClose   from '../commands/tickets/ticketclose.js';
import { handleVerifyButton } from '../commands/admin/setupverify.js';
import { pullmembersimport }  from '../commands/admin/pullcommands.js';
import { ownerhelp }          from '../commands/owner/ownerCommands.js';

const processing = new Set();

export default {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (processing.has(interaction.id)) return;
        processing.add(interaction.id);
        setTimeout(() => processing.delete(interaction.id), 15000);

        // Blacklist check
        if (interaction.guild) {
            const cfg = await GuildConfig.findOne({ guildId: interaction.guild.id });
            if (cfg?.blacklisted) { processing.delete(interaction.id); return; }
        }

        // ── Slash Commands ─────────────────────────────────────────────────────
        if (interaction.isChatInputCommand()) {
            const cmd = client.commands.get(interaction.commandName);
            if (!cmd) return;
            try {
                await cmd.execute({ client, interaction });
            } catch (err) {
                console.error(`[CMD] /${interaction.commandName}:`, err);
                const c = RocksUI.buildStatusMessage('error', 'An error occurred.');
                try {
                    if (interaction.replied || interaction.deferred) await interaction.followUp({ components: c, flags: RocksUI.getFlags(true) });
                    else await interaction.reply({ components: c, flags: RocksUI.getFlags(true) });
                } catch { /* dead */ }
            }
            return;
        }

        // ── Buttons ────────────────────────────────────────────────────────────
        if (interaction.isButton()) {
            const { customId } = interaction;
            try {
                // AntiNuke panel
                if (customId.startsWith('an_')) return await antinukeCmd.handleButton(interaction, client);
                // Backup confirm/cancel
                if (customId.startsWith('bk_')) return await backupCmd.handleButton(interaction, client);
                // Help categories
                if (customId.startsWith('help_cat_')) return await helpCmd.handleButton(interaction, client);
                // Owner help sections
                if (customId.startsWith('ownerhelp_')) return await ownerhelp.handleButton(interaction, client);
                // Verify button in channel
                if (customId.startsWith('verify_btn_')) return await handleVerifyButton(interaction);
                // Ticket open
                if (customId === 'ticket_open_middleman' || customId === 'ticket_open_support') return await panelCmd.handleOpenButton(interaction, client);
                // Ticket close
                if (customId.startsWith('ticket_close_')) return await ticketClose.handleCloseButton(interaction);
                // Ticket claim
                if (customId.startsWith('ticket_claim_')) return await ticketClose.handleClaimButton(interaction);
                // Import approve/deny (owner DMs)
                if (customId.startsWith('import_')) return await pullmembersimport.handleImportButton(interaction, client);
            } catch (err) {
                console.error(`[BUTTON] ${customId}:`, err);
            }
        }

        // ── Select Menus (fullsetup wizard) ────────────────────────────────────
        if (interaction.isChannelSelectMenu() || interaction.isRoleSelectMenu()) {
            // Handled by collectors inside fullsetup wizard — no global handler needed
        }
    },
};
