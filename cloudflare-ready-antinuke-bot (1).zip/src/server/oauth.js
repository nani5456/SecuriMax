import express from 'express';
import fetch   from 'node-fetch';
import path    from 'path';
import { fileURLToPath } from 'url';
import BackupUser  from '../database/schemas/BackupUser.js';
import GuildConfig from '../database/schemas/GuildConfig.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
let _client = null;
export const setClient = (c) => { _client = c; };

// Build the OAuth2 URL for a specific user+guild
export function buildOAuthURL(guildId, userId) {
    const params = new URLSearchParams({
        client_id:     process.env.DISCORD_CLIENT_ID,
        redirect_uri:  process.env.REDIRECT_URI,
        response_type: 'code',
        scope:         'identify guilds.join',
        state:         Buffer.from(JSON.stringify({ guildId, userId })).toString('base64'),
    });
    return `https://discord.com/oauth2/authorize?${params}`;
}

// Force-add user to guild via API
export async function forceAddToGuild(guildId, userId, accessToken) {
    const res = await fetch(`https://discord.com/api/guilds/${guildId}/members/${userId}`, {
        method: 'PUT',
        headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ access_token: accessToken }),
    });
    return res.status;
}

export function startOAuthServer() {
    const app = express();
    app.use(express.static(path.join(__dirname, 'public')));

    // Verify landing page
    app.get('/verify', (req, res) => {
        const { guild, user } = req.query;
        if (!guild || !user) return res.redirect('/error.html');
        const oauthUrl = buildOAuthURL(guild, user);
        res.send(`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Verify</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet"/>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#0f0f23,#1a1a3e,#0d0d1f);font-family:'Inter',sans-serif;color:#fff}
.card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:20px;padding:48px 40px;max-width:440px;width:90%;text-align:center;backdrop-filter:blur(20px);box-shadow:0 25px 50px rgba(0,0,0,.5)}
.shield{font-size:56px;margin-bottom:16px}
h1{font-size:26px;font-weight:700;margin-bottom:8px;background:linear-gradient(90deg,#fff,#b9bffe);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
p{color:rgba(255,255,255,.6);font-size:14px;line-height:1.6;margin-bottom:32px}
.btn{display:inline-flex;align-items:center;gap:10px;background:#5865f2;color:#fff;text-decoration:none;padding:14px 32px;border-radius:12px;font-weight:600;font-size:15px;transition:all .2s;box-shadow:0 4px 15px rgba(88,101,242,.4)}
.btn:hover{background:#4752c4;transform:translateY(-2px)}
.note{margin-top:24px;font-size:12px;color:rgba(255,255,255,.3)}
</style>
</head>
<body>
<div class="card">
  <div class="shield">🛡️</div>
  <h1>Server Verification</h1>
  <p>Click the button below to verify your account and gain access to the server.</p>
  <a class="btn" href="${oauthUrl}">🔐 Verify with Discord</a>
  <p class="note">Only your Discord ID is stored. No personal data is collected.</p>
</div>
</body>
</html>`);
    });

    // OAuth2 Callback
    app.get('/callback', async (req, res) => {
        const { code, state, error } = req.query;
        if (error || !code || !state) return res.redirect('/error.html');

        let guildId, userId;
        try {
            ({ guildId, userId } = JSON.parse(Buffer.from(state, 'base64').toString()));
        } catch { return res.redirect('/error.html'); }

        try {
            // Exchange code for tokens
            const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    client_id: process.env.DISCORD_CLIENT_ID,
                    client_secret: process.env.DISCORD_CLIENT_SECRET,
                    grant_type: 'authorization_code',
                    code,
                    redirect_uri: process.env.REDIRECT_URI,
                }),
            });
            const tokenData = await tokenRes.json();
            if (!tokenData.access_token) return res.redirect('/error.html');

            // Get Discord user
            const userRes = await fetch('https://discord.com/api/users/@me', {
                headers: { Authorization: `Bearer ${tokenData.access_token}` },
            });
            const discordUser = await userRes.json();
            if (!discordUser.id) return res.redirect('/error.html');

            const expiresAt = Date.now() + tokenData.expires_in * 1000;
            const avatar    = discordUser.avatar
                ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png?size=128`
                : `https://cdn.discordapp.com/embed/avatars/${Number(BigInt(discordUser.id) >> 22n) % 6}.png`;

            // Save/update token
            await BackupUser.findOneAndUpdate(
                { userId: discordUser.id },
                {
                    userId:       discordUser.id,
                    username:     discordUser.username,
                    avatar,
                    accessToken:  tokenData.access_token,
                    refreshToken: tokenData.refresh_token,
                    expiresAt,
                    status:       'active',
                    $addToSet:    { guilds: guildId },
                },
                { upsert: true, new: true }
            );

            // Force-add to guild
            await forceAddToGuild(guildId, discordUser.id, tokenData.access_token);

            // Assign roles
            if (_client) {
                const guild  = _client.guilds.cache.get(guildId);
                const cfg    = guild ? await GuildConfig.findOne({ guildId }) : null;
                if (guild && cfg?.verify) {
                    const member = await guild.members.fetch(discordUser.id).catch(() => null);
                    if (member) {
                        if (cfg.verify.memberRoleId)     await member.roles.add(cfg.verify.memberRoleId).catch(() => {});
                        if (cfg.verify.unverifiedRoleId) await member.roles.remove(cfg.verify.unverifiedRoleId).catch(() => {});
                    }
                }
            }

            res.redirect('/success.html');
        } catch (err) {
            console.error('[OAuth]', err);
            res.redirect('/error.html');
        }
    });

    const port = process.env.PORT || 3000;
    app.listen(port, () => console.log(`[OAuth] Server on port ${port}`));
}
