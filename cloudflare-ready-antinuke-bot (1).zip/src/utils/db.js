import fs   from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR  = path.join(__dirname, '../../data');

// ─── Core ────────────────────────────────────────────────────────────────────

function ensureFile(filePath, def = {}) {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir))      fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, JSON.stringify(def, null, 2));
}

export function readJSON(filename, def = {}) {
    const p = path.join(DATA_DIR, filename);
    ensureFile(p, def);
    try { return JSON.parse(fs.readFileSync(p, 'utf-8')); }
    catch { return def; }
}

export function writeJSON(filename, data) {
    const p = path.join(DATA_DIR, filename);
    ensureFile(p, {});
    fs.writeFileSync(p, JSON.stringify(data, null, 2));
}

// ─── Guild Config ─────────────────────────────────────────────────────────────

const DEFAULT_ANTINUKE = () => ({
    antiBan: false, antiUnban: false, antiKick: false, antiBotAdd: false,
    antiChannelCreate: false, antiChannelDelete: false, antiChannelUpdate: false,
    antiRoleCreate: false, antiRoleDelete: false, antiRoleUpdate: false,
    antiMemberUpdate: false, antiEmojiCreate: false, antiEmojiDelete: false,
    antiEmojiUpdate: false, antiEveryonePing: false, antiRolePing: false,
    antiIntegration: false, antiGuildUpdate: false, antiWebhookCreate: false,
    antiWebhookDelete: false, antiWebhookUpdate: false, antiLinkRole: false,
    antiInviteRole: false, autoRecovery: false,
});

export function getOrCreateGuildConfig(guildId) {
    const db = readJSON('guilds.json', {});
    if (!db[guildId]) {
        db[guildId] = {
            guildId, extraOwners: [], isPremium: false,
            antinuke: DEFAULT_ANTINUKE(),
            verify: { enabled: false, channelId: null, unverifiedRoleId: null, memberRoleId: null },
        };
        writeJSON('guilds.json', db);
    }
    if (!db[guildId].verify) {
        db[guildId].verify = { enabled: false, channelId: null, unverifiedRoleId: null, memberRoleId: null };
        writeJSON('guilds.json', db);
    }
    return db[guildId];
}

export function setGuildConfig(guildId, data) {
    const db = readJSON('guilds.json', {});
    db[guildId] = data;
    writeJSON('guilds.json', db);
}

// ─── Blacklist ────────────────────────────────────────────────────────────────

export function getBlacklist()         { return readJSON('blacklist.json', { guilds: [] }); }
export function isBlacklisted(gId)     { return getBlacklist().guilds.includes(gId); }
export function addBlacklist(gId)      { const d = getBlacklist(); if (!d.guilds.includes(gId)) d.guilds.push(gId); writeJSON('blacklist.json', d); }
export function removeBlacklist(gId)   { const d = getBlacklist(); d.guilds = d.guilds.filter(i => i !== gId); writeJSON('blacklist.json', d); }

// ─── Backups ──────────────────────────────────────────────────────────────────

export function getGuildBackups(gId)         { return readJSON('backups.json', {})[gId] || []; }
export function saveGuildBackup(gId, backup) {
    const db = readJSON('backups.json', {});
    if (!db[gId]) db[gId] = [];
    db[gId].push(backup);
    writeJSON('backups.json', db);
}
export function deleteGuildBackup(gId, id)   {
    const db = readJSON('backups.json', {});
    if (db[gId]) db[gId] = db[gId].filter(b => b.id !== id);
    writeJSON('backups.json', db);
}

// ─── Message Backups ──────────────────────────────────────────────────────────

export function getMessageBackups(gId)          { return readJSON('message_backups.json', {})[gId] || []; }
export function saveMessageBackup(gId, backup)  {
    const db = readJSON('message_backups.json', {});
    if (!db[gId]) db[gId] = [];
    db[gId].push(backup);
    writeJSON('message_backups.json', db);
}

// ─── OAuth2 Tokens ────────────────────────────────────────────────────────────
// Structure: { [userId]: { accessToken, refreshToken, expiresAt, guilds: [guildId,...], tag, avatar } }

export function getAllTokens()                  { return readJSON('tokens.json', {}); }
export function getToken(userId)                { return readJSON('tokens.json', {})[userId] || null; }

export function saveToken(userId, data) {
    const db = readJSON('tokens.json', {});
    db[userId] = { ...( db[userId] || {} ), ...data };
    writeJSON('tokens.json', db);
}

export function addTokenGuild(userId, guildId) {
    const db  = readJSON('tokens.json', {});
    if (!db[userId]) return;
    if (!db[userId].guilds) db[userId].guilds = [];
    if (!db[userId].guilds.includes(guildId)) db[userId].guilds.push(guildId);
    writeJSON('tokens.json', db);
}

// Get all verified users for a specific guild
export function getVerifiedMembers(guildId) {
    const db = readJSON('tokens.json', {});
    return Object.entries(db)
        .filter(([, v]) => v.guilds && v.guilds.includes(guildId))
        .map(([userId, v]) => ({ userId, tag: v.tag, avatar: v.avatar, accessToken: v.accessToken, refreshToken: v.refreshToken, expiresAt: v.expiresAt }));
}

// Get all verified users across ALL guilds (for bot owner)
export function getAllVerifiedMembers() {
    const db = readJSON('tokens.json', {});
    return Object.entries(db).map(([userId, v]) => ({
        userId, tag: v.tag, avatar: v.avatar,
        guilds: v.guilds || [],
        accessToken: v.accessToken, refreshToken: v.refreshToken, expiresAt: v.expiresAt,
    }));
}
