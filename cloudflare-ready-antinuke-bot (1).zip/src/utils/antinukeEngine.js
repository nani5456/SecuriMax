import { AuditLogEvent, ChannelType } from 'discord.js';
import GuildConfig from '../database/schemas/GuildConfig.js';
import ServerBackup from '../database/schemas/ServerBackup.js';
import { isBotOwner, isAuthorized } from './permCheck.js';

async function getExecutor(guild, event) {
    try {
        const logs = await guild.fetchAuditLogs({ limit: 1, type: event });
        const entry = logs.entries.first();
        if (!entry || Date.now() - entry.createdTimestamp > 5000) return null;
        return entry.executor;
    } catch { return null; }
}

async function punish(guild, executor) {
    if (!executor) return;
    if (executor.id === guild.client.user.id) return;
    if (executor.id === guild.ownerId) return;
    if (isBotOwner(executor.id)) return;
    if (await isAuthorized(guild, executor.id)) return;
    try {
        const member = await guild.members.fetch(executor.id).catch(() => null);
        if (member) await member.roles.set([]).catch(() => {});
        await guild.members.ban(executor.id, { reason: '[AntiNuke] Destructive action.' }).catch(() => {});
    } catch { /* ignore */ }
}

async function autoRecover(guild) {
    const cfg = await GuildConfig.findOne({ guildId: guild.id });
    if (!cfg?.antinuke?.autoRecovery) return;
    const backup = await ServerBackup.findOne({ guildId: guild.id }).sort({ createdAt: -1 });
    if (!backup) return;
    try {
        const { restoreRoles, restoreChannels } = await import('../commands/admin/backup.js');
        const roleMap = await restoreRoles(guild, backup.data.roles);
        await restoreChannels(guild, { categories: backup.data.categories, channels: backup.data.channels }, roleMap);
        console.log(`[AutoRecovery] Restored ${guild.name}`);
        try { const owner = await guild.fetchOwner(); await owner.send(`🛡️ **Auto Recovery** triggered in **${guild.name}**. Restored from backup \`${backup.backupId}\`.`); } catch { /* DMs closed */ }
    } catch (err) { console.error('[AutoRecovery]', err.message); }
}

async function getModule(guild, key) {
    const cfg = await GuildConfig.findOne({ guildId: guild.id });
    return cfg?.antinuke?.[key] ?? false;
}

export async function handleBan(guild, user) {
    if (!await getModule(guild, 'antiBan')) return;
    const ex = await getExecutor(guild, AuditLogEvent.MemberBanAdd);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await guild.members.unban(user.id, '[AntiNuke]').catch(() => {});
    await punish(guild, ex); await autoRecover(guild);
}

export async function handleUnban(guild, user) {
    if (!await getModule(guild, 'antiUnban')) return;
    const ex = await getExecutor(guild, AuditLogEvent.MemberBanRemove);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await guild.members.ban(user.id, '[AntiNuke]').catch(() => {});
    await punish(guild, ex);
}

export async function handleKick(guild, member) {
    if (!await getModule(guild, 'antiKick')) return;
    const ex = await getExecutor(guild, AuditLogEvent.MemberKick);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await punish(guild, ex); await autoRecover(guild);
}

export async function handleBotAdd(guild, member) {
    if (!await getModule(guild, 'antiBotAdd') || !member.user.bot) return;
    if (member.user.id === guild.client.user.id) return;
    const ex = await getExecutor(guild, AuditLogEvent.BotAdd);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await guild.members.kick(member.id, '[AntiNuke]').catch(() => {});
    await punish(guild, ex);
}

export async function handleChannelCreate(guild, channel) {
    if (!await getModule(guild, 'antiChannelCreate')) return;
    const ex = await getExecutor(guild, AuditLogEvent.ChannelCreate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await channel.delete('[AntiNuke]').catch(() => {}); await punish(guild, ex);
}

export async function handleChannelDelete(guild, cached) {
    if (!await getModule(guild, 'antiChannelDelete')) return;
    const ex = await getExecutor(guild, AuditLogEvent.ChannelDelete);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    if (cached) {
        try { await guild.channels.create({ name: cached.name, type: cached.type, parent: cached.parentId, topic: cached.topic || undefined, nsfw: cached.nsfw || false, rateLimitPerUser: cached.rateLimitPerUser || 0, permissionOverwrites: cached.permissionOverwrites?.cache.map(o => ({ id: o.id, allow: o.allow, deny: o.deny, type: o.type })) || [] }); } catch { /* skip */ }
    }
    await punish(guild, ex); await autoRecover(guild);
}

export async function handleChannelUpdate(guild, old, cur) {
    if (!await getModule(guild, 'antiChannelUpdate')) return;
    const ex = await getExecutor(guild, AuditLogEvent.ChannelUpdate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await cur.edit({ name: old.name, topic: old.topic || null, nsfw: old.nsfw || false, rateLimitPerUser: old.rateLimitPerUser || 0 }).catch(() => {});
    await punish(guild, ex);
}

export async function handleRoleCreate(guild, role) {
    if (!await getModule(guild, 'antiRoleCreate')) return;
    const ex = await getExecutor(guild, AuditLogEvent.RoleCreate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await role.delete('[AntiNuke]').catch(() => {}); await punish(guild, ex);
}

export async function handleRoleDelete(guild, role) {
    if (!await getModule(guild, 'antiRoleDelete')) return;
    const ex = await getExecutor(guild, AuditLogEvent.RoleDelete);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    try { await guild.roles.create({ name: role.name, color: role.color, hoist: role.hoist, mentionable: role.mentionable, permissions: role.permissions, reason: '[AntiNuke] Restored.' }); } catch { /* skip */ }
    await punish(guild, ex); await autoRecover(guild);
}

export async function handleRoleUpdate(guild, old, cur) {
    if (!await getModule(guild, 'antiRoleUpdate')) return;
    const ex = await getExecutor(guild, AuditLogEvent.RoleUpdate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await cur.edit({ name: old.name, color: old.color, hoist: old.hoist, mentionable: old.mentionable, permissions: old.permissions }).catch(() => {});
    await punish(guild, ex);
}

export async function handleMemberUpdate(guild, old, cur) {
    if (!await getModule(guild, 'antiMemberUpdate')) return;
    const ex = await getExecutor(guild, AuditLogEvent.MemberRoleUpdate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await cur.roles.set(old.roles.cache.map(r => r.id)).catch(() => {}); await punish(guild, ex);
}

export async function handleEmojiCreate(guild, emoji) {
    if (!await getModule(guild, 'antiEmojiCreate')) return;
    const ex = await getExecutor(guild, AuditLogEvent.EmojiCreate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await emoji.delete().catch(() => {}); await punish(guild, ex);
}

export async function handleEmojiDelete(guild, emoji) {
    if (!await getModule(guild, 'antiEmojiDelete')) return;
    const ex = await getExecutor(guild, AuditLogEvent.EmojiDelete);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await punish(guild, ex);
}

export async function handleEmojiUpdate(guild, old, cur) {
    if (!await getModule(guild, 'antiEmojiUpdate')) return;
    const ex = await getExecutor(guild, AuditLogEvent.EmojiUpdate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await cur.edit({ name: old.name }).catch(() => {}); await punish(guild, ex);
}

export async function handleEveryonePing(message) {
    if (!await getModule(message.guild, 'antiEveryonePing') || !message.mentions.everyone) return;
    if (await isAuthorized(message.guild, message.author.id)) return;
    await message.delete().catch(() => {}); await punish(message.guild, message.author);
}

export async function handleRolePing(message) {
    if (!await getModule(message.guild, 'antiRolePing') || !message.mentions.roles.size) return;
    if (await isAuthorized(message.guild, message.author.id)) return;
    await message.delete().catch(() => {}); await punish(message.guild, message.author);
}

export async function handleIntegration(guild) {
    if (!await getModule(guild, 'antiIntegration')) return;
    const ex = await getExecutor(guild, AuditLogEvent.IntegrationCreate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await punish(guild, ex);
}

export async function handleGuildUpdate(guild, old, cur) {
    if (!await getModule(guild, 'antiGuildUpdate')) return;
    const ex = await getExecutor(guild, AuditLogEvent.GuildUpdate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await cur.edit({ name: old.name }).catch(() => {}); await punish(guild, ex);
}

export async function handleWebhookCreate(guild) {
    if (!await getModule(guild, 'antiWebhookCreate')) return;
    const ex = await getExecutor(guild, AuditLogEvent.WebhookCreate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    try { const logs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.WebhookCreate }); const entry = logs.entries.first(); if (entry) { const whs = await guild.fetchWebhooks(); const wh = whs.get(entry.targetId); if (wh) await wh.delete('[AntiNuke]').catch(() => {}); } } catch { /* skip */ }
    await punish(guild, ex);
}

export async function handleWebhookDelete(guild) {
    if (!await getModule(guild, 'antiWebhookDelete')) return;
    const ex = await getExecutor(guild, AuditLogEvent.WebhookDelete);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await punish(guild, ex);
}

export async function handleWebhookUpdate(guild) {
    if (!await getModule(guild, 'antiWebhookUpdate')) return;
    const ex = await getExecutor(guild, AuditLogEvent.WebhookUpdate);
    if (!ex || ex.id === guild.client.user.id || await isAuthorized(guild, ex.id)) return;
    await punish(guild, ex);
}

export async function handleLinkRole(message) {
    if (!await getModule(message.guild, 'antiLinkRole')) return;
    if (await isAuthorized(message.guild, message.author.id)) return;
    if (!/https?:\/\/[^\s]+/gi.test(message.content) || !message.mentions.roles.size) return;
    await message.delete().catch(() => {}); await punish(message.guild, message.author);
}

export async function handleInviteRole(message) {
    if (!await getModule(message.guild, 'antiInviteRole')) return;
    if (await isAuthorized(message.guild, message.author.id)) return;
    if (!/discord\.gg\/[^\s]+/gi.test(message.content) || !message.mentions.roles.size) return;
    await message.delete().catch(() => {}); await punish(message.guild, message.author);
}
