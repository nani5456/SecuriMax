import {
    ChannelType, PermissionFlagsBits, PermissionsBitField,
    ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder,
    TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags,
} from 'discord.js';
import { buildOAuthURL } from '../server/oauth.js';
import { getOrCreateGuildConfig, setGuildConfig } from './db.js';
import { config } from '../config/config.js';

// ─── Build the verification panel message ─────────────────────────────────────
export function buildVerifyPanel(guildId, userId) {
    const url = `${process.env.REDIRECT_URI.replace('/callback', '')}/verify?guild=${guildId}&user=${userId}`;

    const container = new ContainerBuilder();
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `### 🛡️ Server Verification Required\n`
    ));
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `${config.emojis.dot} This server requires you to verify before gaining access.\n` +
        `${config.emojis.dot} Click the button below to complete verification.\n` +
        `${config.emojis.dot} This only takes a few seconds.`
    ));
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
    container.addActionRowComponents(
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel('🔐 Verify Now')
                .setStyle(ButtonStyle.Link)
                .setURL(url)
        )
    );
    container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));

    return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

// ─── Send DM panel to a single user ──────────────────────────────────────────
export async function sendVerifyDM(user, guildId, guildName) {
    try {
        const url = `${process.env.REDIRECT_URI.replace('/callback', '')}/verify?guild=${guildId}&user=${user.id}`;

        const container = new ContainerBuilder();
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`### 🛡️ Verify in **${guildName}**`));
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `${config.emojis.dot} You joined **${guildName}** and need to verify to get access.\n` +
            `${config.emojis.dot} Click the button below — it only takes 2 seconds.\n` +
            `${config.emojis.dot} If the button doesn't work, use this link:\n${url}`
        ));
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
        container.addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setLabel('🔐 Verify Now').setStyle(ButtonStyle.Link).setURL(url)
            )
        );
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));

        await user.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        return true;
    } catch { return false; } // DMs closed
}

// ─── Setup verification system in a guild ────────────────────────────────────
export async function setupVerification(guild) {
    const cfg = getOrCreateGuildConfig(guild.id);

    // Create or find "Unverified" role
    let unverifiedRole = guild.roles.cache.find(r => r.name === 'Unverified');
    if (!unverifiedRole) {
        unverifiedRole = await guild.roles.create({
            name: 'Unverified',
            color: '#99aab5',
            reason: '[Verify System] Auto-created.',
            permissions: [],
        });
    }

    // Create or find "Member" role
    let memberRole = guild.roles.cache.find(r => r.name === 'Member');
    if (!memberRole) {
        memberRole = await guild.roles.create({
            name: 'Member',
            color: '#57f287',
            reason: '[Verify System] Auto-created.',
        });
    }

    // Lock ALL channels from Unverified
    for (const [, ch] of guild.channels.cache) {
        try {
            await ch.permissionOverwrites.edit(unverifiedRole, {
                ViewChannel: false,
                SendMessages: false,
            });
        } catch { /* skip locked channels */ }
    }

    // Create or find #verify channel
    let verifyChannel = guild.channels.cache.find(c => c.name === 'verify' && c.type === ChannelType.GuildText);
    if (!verifyChannel) {
        verifyChannel = await guild.channels.create({
            name: 'verify',
            type: ChannelType.GuildText,
            reason: '[Verify System] Verification channel.',
            permissionOverwrites: [
                // @everyone — cannot see
                { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                // Unverified — can see + read only
                { id: unverifiedRole.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory], deny: [PermissionFlagsBits.SendMessages] },
                // Bot — full access
                { id: guild.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageMessages] },
            ],
        });
    } else {
        // Update permissions on existing channel
        await verifyChannel.permissionOverwrites.set([
            { id: guild.id,                deny: [PermissionFlagsBits.ViewChannel] },
            { id: unverifiedRole.id,        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory], deny: [PermissionFlagsBits.SendMessages] },
            { id: guild.client.user.id,     allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageMessages] },
        ]);
    }

    // Post the verification panel in the channel (a generic one without user-specific URL)
    await verifyChannel.bulkDelete(10).catch(() => {});
    const panelContainer = new ContainerBuilder();
    panelContainer.addTextDisplayComponents(new TextDisplayBuilder().setContent(`### 🛡️ Verification Required — ${guild.name}`));
    panelContainer.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
    panelContainer.addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `${config.emojis.dot} Welcome! To access this server you need to verify your account.\n` +
        `${config.emojis.dot} Check your **Direct Messages** — we sent you a personal verify link.\n` +
        `${config.emojis.dot} If your DMs are closed, open them and rejoin the server.`
    ));
    panelContainer.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
    await verifyChannel.send({ components: [panelContainer], flags: MessageFlags.IsComponentsV2 });

    // Save to config
    cfg.verify = {
        enabled: true,
        channelId: verifyChannel.id,
        unverifiedRoleId: unverifiedRole.id,
        memberRoleId: memberRole.id,
    };
    setGuildConfig(guild.id, cfg);

    return { verifyChannel, unverifiedRole, memberRole };
}
