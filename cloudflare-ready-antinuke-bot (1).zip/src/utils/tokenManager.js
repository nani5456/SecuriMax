import fetch from 'node-fetch';
import BackupUser from '../database/schemas/BackupUser.js';

export async function getValidToken(userId) {
    const user = await BackupUser.findOne({ userId, status: 'active' });
    if (!user) throw new Error('User not found in backup database.');

    // If token is still valid (with 60s buffer)
    if (Date.now() < user.expiresAt - 60000) {
        return user.accessToken;
    }

    // Refresh the token
    const res = await fetch('https://discord.com/api/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            client_id:     process.env.DISCORD_CLIENT_ID,
            client_secret: process.env.DISCORD_CLIENT_SECRET,
            grant_type:    'refresh_token',
            refresh_token: user.refreshToken,
        }),
    });

    const data = await res.json();
    if (!data.access_token) throw new Error('Token refresh failed.');

    user.accessToken  = data.access_token;
    user.refreshToken = data.refresh_token;
    user.expiresAt    = Date.now() + data.expires_in * 1000;
    await user.save();

    return user.accessToken;
}

export const sleep = (ms) => new Promise(r => setTimeout(r, ms));
