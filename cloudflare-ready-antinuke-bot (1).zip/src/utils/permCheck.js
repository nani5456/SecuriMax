import GuildConfig from '../database/schemas/GuildConfig.js';

export const isBotOwner    = (userId) => userId === process.env.OWNER_ID;
export const isServerOwner = (guild, userId) => guild.ownerId === userId;

export async function isExtraOwner(guildId, userId) {
    const cfg = await GuildConfig.findOne({ guildId });
    return cfg?.extraOwners?.includes(userId) ?? false;
}

export async function isAuthorized(guild, userId) {
    if (isBotOwner(userId)) return true;
    if (isServerOwner(guild, userId)) return true;
    return await isExtraOwner(guild.id, userId);
}

export async function isPremiumAuthorized(guild, userId) {
    if (isBotOwner(userId)) return { ok: true };
    const cfg = await GuildConfig.findOne({ guildId: guild.id });
    if (!cfg?.isPremium) return { ok: false, reason: 'nopremium' };
    const auth = await isAuthorized(guild, userId);
    if (!auth) return { ok: false, reason: 'noperms' };
    return { ok: true };
}

export async function getOrCreateConfig(guildId) {
    let cfg = await GuildConfig.findOne({ guildId });
    if (!cfg) cfg = await GuildConfig.create({ guildId });
    return cfg;
}
