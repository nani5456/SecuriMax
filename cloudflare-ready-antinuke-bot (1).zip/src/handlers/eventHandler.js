import chalk from 'chalk';
import events from '../events/events.js';
import interactionCreate from '../events/interactionCreate.js';

export const loadEvents = (client) => {
    const all = [...events, interactionCreate];
    for (const event of all) {
        const fn = (...args) => event.execute(...args, client);
        event.once ? client.once(event.name, fn) : client.on(event.name, fn);
        console.log(chalk.cyan(`[EVENT] ${event.name}`));
    }
};
