import { Collection, REST, Routes } from 'discord.js';
import chalk from 'chalk';

// Admin
import antinuke        from '../commands/admin/antinuke.js';
import extraowner      from '../commands/admin/extraowner.js';
import backup          from '../commands/admin/backup.js';
import messagebackup   from '../commands/admin/messagebackup.js';
import setupverify     from '../commands/admin/setupverify.js';
import help            from '../commands/admin/help.js';
import { pullmember, pullablemembers, pullmembersimport } from '../commands/admin/pullcommands.js';

// Tickets
import fullsetup  from '../commands/tickets/fullsetup.js';
import panel      from '../commands/tickets/panel.js';
import ticketclose from '../commands/tickets/ticketclose.js';
import { ticketadd, rename } from '../commands/tickets/ticketutils.js';

// Owner
import {
    ping, getinvite, leaveguild,
    blacklistguildadd, removeblacklist,
    premiumaguild, ticketguild,
    botownpull, broadcast, ownerhelp,
} from '../commands/owner/ownerCommands.js';

const ALL = [
    antinuke, extraowner, backup, messagebackup, setupverify, help,
    pullmember, pullablemembers, pullmembersimport,
    fullsetup, panel, ticketclose, ticketadd, rename,
    ping, getinvite, leaveguild, blacklistguildadd, removeblacklist,
    premiumaguild, ticketguild, botownpull, broadcast, ownerhelp,
];

export const loadCommands = async (client) => {
    client.commands = new Collection();
    const data = [];

    for (const cmd of ALL) {
        client.commands.set(cmd.data.name, cmd);
        data.push(cmd.data.toJSON());
        console.log(chalk.blue(`[CMD] /${cmd.data.name}`));
    }

    const rest = new REST().setToken(process.env.DISCORD_TOKEN);
    try {
        console.log(chalk.yellow('[API] Registering slash commands...'));
        await rest.put(Routes.applicationCommands(client.user.id), { body: data });
        console.log(chalk.green(`[API] ${data.length} commands registered.`));
    } catch (err) {
        console.error(chalk.red('[API] Failed:'), err);
    }
};
