import {
    ContainerBuilder, TextDisplayBuilder, SeparatorBuilder,
    SeparatorSpacingSize, MessageFlags, ActionRowBuilder,
    MediaGalleryBuilder, MediaGalleryItemBuilder,
} from 'discord.js';
import { config } from '../../config/config.js';

export class RocksUI {
    static getFlags(ephemeral = false) {
        let f = MessageFlags.IsComponentsV2;
        if (ephemeral) f |= MessageFlags.Ephemeral;
        return f;
    }

    static buildSimpleMessage(content) {
        const c = new ContainerBuilder();
        c.addTextDisplayComponents(new TextDisplayBuilder().setContent(content));
        return [c];
    }

    static buildStatusMessage(type, content) {
        const icons = { success: config.emojis.tick, error: config.emojis.cross, dot: config.emojis.dot, loader: config.emojis.loader };
        const icon = icons[type] || config.emojis.dot;
        return this.buildSimpleMessage(`${icon} ${content}`);
    }

    static buildDashboard(title, description, rows = []) {
        const c = new ContainerBuilder();
        c.addTextDisplayComponents(new TextDisplayBuilder().setContent(title.startsWith('#') ? title : `### ${title}`));
        c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
        c.addTextDisplayComponents(new TextDisplayBuilder().setContent(description));
        if (rows.length) {
            c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
            c.addActionRowComponents(...rows);
        }
        c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
        return [c];
    }

    static buildDetailedDashboard(title, description, fields = [], rows = [], imageUrl = null) {
        const c = new ContainerBuilder();
        c.addTextDisplayComponents(new TextDisplayBuilder().setContent(title.startsWith('#') ? title : `### ${title}`));
        c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
        if (description) c.addTextDisplayComponents(new TextDisplayBuilder().setContent(description));
        if (imageUrl) c.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(imageUrl)));
        if (fields.length) {
            if (description) c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
            c.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                fields.map(f => `${config.emojis.dot} **${f.name}:** ${f.value}`).join('\n')
            ));
        }
        if (rows.length) {
            c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
            c.addActionRowComponents(...rows);
        }
        c.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false));
        return [c];
    }
}
